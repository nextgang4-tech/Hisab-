package com.haweli.pdf

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.CancellationSignal
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import com.haweli.utils.DateAndFormatUtils
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Data structure representing a structured Hindi accounting report ready for PDF rendering.
 */
data class PdfReportDocumentData(
    val reportTitleHindi: String,
    val subtitleHindi: String,
    val partyOrSectionName: String,
    val dateRangeLabel: String,
    val previousBalance: String,
    val totalAmount: String,
    val totalPaidOrReceived: String,
    val finalBalance: String,
    val finalBalanceStatus: String,
    val monthlySummaryLines: List<String> = emptyList(),
    val tableHeaders: List<String>,
    val tableRows: List<List<String>>,
    val paymentColumnIndex: Int = -1
)

/**
 * Native Android PdfDocument generator with full Devanagari / Hindi font rendering,
 * multi-page pagination, WhatsApp sharing, generic app sharing, Downloads saving, and printing.
 */
object HaweliPdfGenerator {

    private const val PAGE_WIDTH = 595 // A4 width in points
    private const val PAGE_HEIGHT = 842 // A4 height in points
    private const val MARGIN = 28f

    private val COLOR_NAVY = Color.parseColor("#102A56")
    private val COLOR_DARK_GREEN = Color.parseColor("#0D5C3A")
    private val COLOR_PAYMENT_RED = Color.parseColor("#C62828")
    private val COLOR_POSITIVE_GREEN = Color.parseColor("#1B7A43")
    private val COLOR_HEADER_BG = Color.parseColor("#E8F1EC")
    private val COLOR_ROW_ALT = Color.parseColor("#F7F9FA")
    private val COLOR_BORDER = Color.parseColor("#B0BEC5")

    fun generatePdfFile(context: Context, data: PdfReportDocumentData): File {
        val pdfDocument = PdfDocument()
        val hindiTypeface = Typeface.create("sans-serif", Typeface.NORMAL)
        val hindiBoldTypeface = Typeface.create("sans-serif", Typeface.BOLD)

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = hindiBoldTypeface
            textSize = 20f
            color = Color.WHITE
        }
        val subHeaderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = hindiTypeface
            textSize = 11f
            color = Color.WHITE
        }
        val sectionTitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = hindiBoldTypeface
            textSize = 13f
            color = COLOR_NAVY
        }
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = hindiTypeface
            textSize = 10.5f
            color = Color.DKGRAY
        }
        val valueBoldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = hindiBoldTypeface
            textSize = 11f
            color = Color.BLACK
        }
        val paymentRedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = hindiBoldTypeface
            textSize = 10f
            color = COLOR_PAYMENT_RED
        }
        val positiveGreenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = hindiBoldTypeface
            textSize = 11f
            color = COLOR_POSITIVE_GREEN
        }
        val tableHeaderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = hindiBoldTypeface
            textSize = 9.5f
            color = COLOR_NAVY
        }
        val tableCellPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = hindiTypeface
            textSize = 9f
            color = Color.BLACK
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
            color = COLOR_BORDER
        }
        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
        }

        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
        var page = pdfDocument.startPage(pageInfo)
        var canvas = page.canvas
        var yPos = drawPageHeader(
            canvas = canvas,
            data = data,
            pageNumber = pageNumber,
            isFirstPage = true,
            titlePaint = titlePaint,
            subHeaderPaint = subHeaderPaint,
            sectionTitlePaint = sectionTitlePaint,
            labelPaint = labelPaint,
            valueBoldPaint = valueBoldPaint,
            paymentRedPaint = paymentRedPaint,
            positiveGreenPaint = positiveGreenPaint,
            fillPaint = fillPaint,
            borderPaint = borderPaint
        )

        val contentWidth = PAGE_WIDTH - (2 * MARGIN)
        val colCount = data.tableHeaders.size.coerceAtLeast(1)
        val colWidth = contentWidth / colCount

        yPos = drawTableHeaderRow(
            canvas = canvas,
            headers = data.tableHeaders,
            yStart = yPos,
            colWidth = colWidth,
            tableHeaderPaint = tableHeaderPaint,
            fillPaint = fillPaint,
            borderPaint = borderPaint
        )

        val rowHeight = 24f
        val bottomLimit = PAGE_HEIGHT - 65f

        data.tableRows.forEachIndexed { rowIndex, rowValues ->
            if (yPos + rowHeight > bottomLimit) {
                drawPageFooter(canvas, pageNumber, labelPaint)
                pdfDocument.finishPage(page)

                pageNumber += 1
                pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
                page = pdfDocument.startPage(pageInfo)
                canvas = page.canvas
                yPos = drawPageHeader(
                    canvas = canvas,
                    data = data,
                    pageNumber = pageNumber,
                    isFirstPage = false,
                    titlePaint = titlePaint,
                    subHeaderPaint = subHeaderPaint,
                    sectionTitlePaint = sectionTitlePaint,
                    labelPaint = labelPaint,
                    valueBoldPaint = valueBoldPaint,
                    paymentRedPaint = paymentRedPaint,
                    positiveGreenPaint = positiveGreenPaint,
                    fillPaint = fillPaint,
                    borderPaint = borderPaint
                )
                yPos = drawTableHeaderRow(
                    canvas = canvas,
                    headers = data.tableHeaders,
                    yStart = yPos,
                    colWidth = colWidth,
                    tableHeaderPaint = tableHeaderPaint,
                    fillPaint = fillPaint,
                    borderPaint = borderPaint
                )
            }

            if (rowIndex % 2 == 1) {
                fillPaint.color = COLOR_ROW_ALT
                canvas.drawRect(MARGIN, yPos, PAGE_WIDTH - MARGIN, yPos + rowHeight, fillPaint)
            }

            for (c in 0 until colCount) {
                val cellLeft = MARGIN + (c * colWidth)
                val cellText = rowValues.getOrNull(c) ?: ""
                val paintToUse = if (c == data.paymentColumnIndex) paymentRedPaint else tableCellPaint
                val clipped = truncateTextToFit(cellText, colWidth - 8f, paintToUse)
                canvas.drawText(clipped, cellLeft + 4f, yPos + 15f, paintToUse)
                canvas.drawRect(cellLeft, yPos, cellLeft + colWidth, yPos + rowHeight, borderPaint)
            }

            yPos += rowHeight
        }

        // Draw Final Summary Footer Block
        if (yPos + 80f > bottomLimit) {
            drawPageFooter(canvas, pageNumber, labelPaint)
            pdfDocument.finishPage(page)
            pageNumber += 1
            pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
            page = pdfDocument.startPage(pageInfo)
            canvas = page.canvas
            yPos = MARGIN + 20f
        }

        yPos += 14f
        fillPaint.color = COLOR_HEADER_BG
        canvas.drawRect(MARGIN, yPos, PAGE_WIDTH - MARGIN, yPos + 54f, fillPaint)
        canvas.drawRect(MARGIN, yPos, PAGE_WIDTH - MARGIN, yPos + 54f, borderPaint)

        canvas.drawText(
            "पिछला बैलेंस: ${DateAndFormatUtils.formatIndianCurrency(data.previousBalance)}",
            MARGIN + 10f,
            yPos + 18f,
            valueBoldPaint
        )
        canvas.drawText(
            "कुल रकम: ${DateAndFormatUtils.formatIndianCurrency(data.totalAmount)}",
            MARGIN + 200f,
            yPos + 18f,
            valueBoldPaint
        )
        canvas.drawText(
            "भुगतान / प्राप्त रकम: ${DateAndFormatUtils.formatIndianCurrency(data.totalPaidOrReceived)}",
            MARGIN + 10f,
            yPos + 38f,
            paymentRedPaint
        )
        val finalPaint = if (data.finalBalance.startsWith("-")) paymentRedPaint else positiveGreenPaint
        canvas.drawText(
            "अंतिम बाकी बैलेंस: ${DateAndFormatUtils.formatIndianCurrency(data.finalBalance)} (${data.finalBalanceStatus})",
            MARGIN + 220f,
            yPos + 38f,
            finalPaint
        )

        drawPageFooter(canvas, pageNumber, labelPaint)
        pdfDocument.finishPage(page)

        val pdfDir = File(context.cacheDir, "pdfs")
        if (!pdfDir.exists()) pdfDir.mkdirs()
        val safeTitle = data.reportTitleHindi.replace(Regex("[^\\p{L}\\p{N}_-]"), "_")
        val outFile = File(pdfDir, "HAWELI_${safeTitle}_${System.currentTimeMillis()}.pdf")

        FileOutputStream(outFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
        return outFile
    }

    private fun drawPageHeader(
        canvas: Canvas,
        data: PdfReportDocumentData,
        pageNumber: Int,
        isFirstPage: Boolean,
        titlePaint: Paint,
        subHeaderPaint: Paint,
        sectionTitlePaint: Paint,
        labelPaint: Paint,
        valueBoldPaint: Paint,
        paymentRedPaint: Paint,
        positiveGreenPaint: Paint,
        fillPaint: Paint,
        borderPaint: Paint
    ): Float {
        var y = MARGIN

        // Top Banner (Dark Green & Navy)
        fillPaint.color = COLOR_DARK_GREEN
        canvas.drawRect(MARGIN, y, PAGE_WIDTH - MARGIN, y + 54f, fillPaint)
        canvas.drawText("HAWELI (हवेली बिज़नेस अकाउंटिंग)", MARGIN + 12f, y + 24f, titlePaint)
        canvas.drawText(
            "${data.reportTitleHindi} | तारीख व समय: ${DateAndFormatUtils.formatTimestamp(System.currentTimeMillis())}",
            MARGIN + 12f,
            y + 44f,
            subHeaderPaint
        )
        y += 62f

        if (isFirstPage) {
            // Party & Date Range Box
            fillPaint.color = COLOR_ROW_ALT
            val boxHeight = if (data.monthlySummaryLines.isEmpty()) 68f else 92f
            canvas.drawRect(MARGIN, y, PAGE_WIDTH - MARGIN, y + boxHeight, fillPaint)
            canvas.drawRect(MARGIN, y, PAGE_WIDTH - MARGIN, y + boxHeight, borderPaint)

            canvas.drawText("पार्टी / विभाग: ${data.partyOrSectionName}", MARGIN + 10f, y + 18f, sectionTitlePaint)
            canvas.drawText("अवधि / फ़िल्टर: ${data.dateRangeLabel}", MARGIN + 300f, y + 18f, labelPaint)

            canvas.drawText(
                "पिछला बैलेंस: ${DateAndFormatUtils.formatIndianCurrency(data.previousBalance)}",
                MARGIN + 10f,
                y + 38f,
                labelPaint
            )
            canvas.drawText(
                "कुल रकम: ${DateAndFormatUtils.formatIndianCurrency(data.totalAmount)}",
                MARGIN + 185f,
                y + 38f,
                valueBoldPaint
            )
            canvas.drawText(
                "भुगतान: ${DateAndFormatUtils.formatIndianCurrency(data.totalPaidOrReceived)}",
                MARGIN + 360f,
                y + 38f,
                paymentRedPaint
            )

            val balPaint = if (data.finalBalance.startsWith("-")) paymentRedPaint else positiveGreenPaint
            canvas.drawText(
                "बाकी बैलेंस: ${DateAndFormatUtils.formatIndianCurrency(data.finalBalance)} (${data.finalBalanceStatus})",
                MARGIN + 10f,
                y + 56f,
                balPaint
            )

            if (data.monthlySummaryLines.isNotEmpty()) {
                val summaryLine = data.monthlySummaryLines.joinToString("  |  ")
                canvas.drawText(
                    truncateTextToFit(summaryLine, PAGE_WIDTH - (2 * MARGIN) - 20f, labelPaint),
                    MARGIN + 10f,
                    y + 78f,
                    labelPaint
                )
            }
            y += boxHeight + 10f
        } else {
            canvas.drawText(
                "${data.partyOrSectionName} - ${data.reportTitleHindi} (पृष्ठ $pageNumber)",
                MARGIN,
                y + 12f,
                sectionTitlePaint
            )
            y += 22f
        }

        return y
    }

    private fun drawTableHeaderRow(
        canvas: Canvas,
        headers: List<String>,
        yStart: Float,
        colWidth: Float,
        tableHeaderPaint: Paint,
        fillPaint: Paint,
        borderPaint: Paint
    ): Float {
        val headerHeight = 26f
        fillPaint.color = COLOR_HEADER_BG
        canvas.drawRect(MARGIN, yStart, PAGE_WIDTH - MARGIN, yStart + headerHeight, fillPaint)

        headers.forEachIndexed { idx, title ->
            val left = MARGIN + (idx * colWidth)
            val clipped = truncateTextToFit(title, colWidth - 8f, tableHeaderPaint)
            canvas.drawText(clipped, left + 4f, yStart + 17f, tableHeaderPaint)
            canvas.drawRect(left, yStart, left + colWidth, yStart + headerHeight, borderPaint)
        }
        return yStart + headerHeight
    }

    private fun drawPageFooter(canvas: Canvas, pageNumber: Int, paint: Paint) {
        val footerY = PAGE_HEIGHT - 18f
        canvas.drawText(
            "HAWELI अकाउंटिंग सिस्टम द्वारा जनरेट किया गया | पृष्ठ $pageNumber",
            MARGIN,
            footerY,
            paint
        )
    }

    private fun truncateTextToFit(text: String, maxWidth: Float, paint: Paint): String {
        if (paint.measureText(text) <= maxWidth) return text
        var trimmed = text
        while (trimmed.length > 3 && paint.measureText("$trimmed…") > maxWidth) {
            trimmed = trimmed.dropLast(1)
        }
        return "$trimmed…"
    }

    /**
     * Saves the generated PDF to the phone's Downloads folder.
     */
    fun savePdfToDownloads(context: Context, pdfFile: File): String {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, pdfFile.name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/HAWELI")
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(pdfFile).use { input -> input.copyTo(out) }
                    }
                    Toast.makeText(
                        context,
                        "पीडीएफ फ़ोन के Downloads/HAWELI फ़ोल्डर में सहेजी गई: ${pdfFile.name}",
                        Toast.LENGTH_LONG
                    ).show()
                    "Downloads/HAWELI/${pdfFile.name}"
                } else {
                    pdfFile.absolutePath
                }
            } else {
                val destDir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                    "HAWELI"
                )
                if (!destDir.exists()) destDir.mkdirs()
                val destFile = File(destDir, pdfFile.name)
                pdfFile.copyTo(destFile, overwrite = true)
                Toast.makeText(
                    context,
                    "पीडीएफ सहेजी गई: ${destFile.absolutePath}",
                    Toast.LENGTH_LONG
                ).show()
                destFile.absolutePath
            }
        } catch (e: Exception) {
            Toast.makeText(
                context,
                "पीडीएफ आंतरिक स्टोरेज में सहेजी गई: ${pdfFile.name}",
                Toast.LENGTH_LONG
            ).show()
            pdfFile.absolutePath
        }
    }

    /**
     * Shares the PDF directly via WhatsApp (if installed) or falls back to system share sheet.
     */
    fun sharePdfViaWhatsApp(context: Context, pdfFile: File, reportTitle: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            pdfFile
        )
        val whatsAppIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            setPackage("com.whatsapp")
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "HAWELI रिपोर्ट: $reportTitle")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            context.startActivity(whatsAppIntent)
        } catch (e: Exception) {
            // Fallback to generic share chooser if standard WhatsApp is not installed (e.g., WhatsApp Business)
            sharePdfGeneric(context, pdfFile, reportTitle)
        }
    }

    /**
     * Shares the PDF through any installed app (Email, Telegram, Drive, WhatsApp Business, etc.).
     */
    fun sharePdfGeneric(context: Context, pdfFile: File, reportTitle: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            pdfFile
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "HAWELI रिपोर्ट - $reportTitle")
            putExtra(Intent.EXTRA_TEXT, "HAWELI बिज़नेस अकाउंटिंग पीडीएफ रिपोर्ट: $reportTitle")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "पीडीएफ रिपोर्ट भेजें"))
    }

    /**
     * Prints the generated PDF file using Android's native PrintManager.
     */
    fun printPdfFile(context: Context, pdfFile: File, jobName: String) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: android.os.Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder(pdfFile.name)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                try {
                    if (destination != null) {
                        FileInputStream(pdfFile).use { input ->
                            FileOutputStream(destination.fileDescriptor).use { output ->
                                input.copyTo(output)
                            }
                        }
                    }
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.localizedMessage)
                }
            }
        }
        printManager.print(jobName, adapter, PrintAttributes.Builder().build())
    }
}
