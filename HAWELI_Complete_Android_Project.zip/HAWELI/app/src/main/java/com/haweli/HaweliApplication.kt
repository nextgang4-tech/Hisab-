package com.haweli

import android.app.Application
import com.google.firebase.FirebaseApp
import com.haweli.firebase.FirebaseClient

/**
 * Application class initializing Firebase and enabling offline disk persistence on startup.
 */
class HaweliApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            FirebaseApp.initializeApp(this)
            FirebaseClient.database
        } catch (_: Exception) {
        }
    }
}
