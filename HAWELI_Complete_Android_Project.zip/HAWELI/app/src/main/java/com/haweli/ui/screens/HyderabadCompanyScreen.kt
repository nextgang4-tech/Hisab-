package com.haweli.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haweli.HaweliViewModel
import com.haweli.admin.AdminOnlySection
import com.haweli.calculations.AccountingCalculator
import com.haweli.models.*
import com.haweli.ui.components.*
import com.haweli.ui.theme.*
import com.haweli.utils.DateAndFormatUtils

/**
 * 5. HYDERABAD COMPANY SCREEN (हैदराबाद कंपनी)
 * Structure: हैदराबाद कंपनी → पार्टी का नाम → पार्टी का हिसाब (14 fields)
 * Received payment displayed in RED colour; updates कुल आना on Home Dashboard automatically.
 */
@Composable
fun HyderabadCompanyScreen(
    viewModel: HaweliViewModel,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val isConnected by viewModel.isConnected.collectAsState()
    val pendingWrites by viewModel.pendingWriteCount.collectAsState()
    val accessRole by viewModel.accessRole.collectAsState()
    val allParties by viewModel.parties.collectAsState()
    val allEntries by viewModel.hyderabadEntries.collectAsState()

    val hydParties = remember(allParties) {
        allParties.filter { it.module == "HYDERABAD" }
    }

    var selectedParty by remember { mutableStateOf<PartyRecord?>(null) }
    val activeParty = remember(selectedParty, hydParties) {
        selectedParty?.let { sel -> hydParties.find { it.id == sel.id } ?: sel }
    }

    var searchQuery by remember { mutableStateOf("") }
    var dateFilter by remember { mutableStateOf("") }
    var monthFilter by remember { mutableStateOf("") }
    var yearFilter by remember { mutableStateOf("") }
    var newestFirst by remember { mutableStateOf(true) }

    var showPartyDialog by remember { mutableStateOf(false) }
    var editingParty by remember { mutableStateOf<PartyRecord?>(null) }
    var partyToDelete by remember { mutableStateOf<PartyRecord?>(null) }

    var showEntryDialog by remember { mutableStateOf(false) }
    var editingEntry by remember { mutableStateOf<HyderabadEntry?>(null) }
    var entryToDelete by remember { mutableStateOf<HyderabadEntry?>(null) }

    Scaffold(
        topBar = {
            HaweliTopBar(
                title = if (activeParty == null) "हैदराबाद कंपनी (पार्टी सूची)" else "हैदराबाद हिसाब: ${activeParty.name}",
                isConnected = isConnected,
                pendingWrites = pendingWrites,
                accessRole = accessRole,
                onBackClick = {
                    if (activeParty != null) selectedParty = null else onBack()
                },
                onSettingsClick = onOpenSettings
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            ModuleSearchAndFilterBar(
                searchQuery = searchQuery,
                onSearchChange = { searchQuery = it },
                searchPlaceholder = "पार्टी का नाम या तारीख खोजें...",
                dateFilter = dateFilter,
                onDateFilterChange = { dateFilter = it },
                monthFilter = monthFilter,
                onMonthFilterChange = { monthFilter = it },
                yearFilter = yearFilter,
                onYearFilterChange = { yearFilter = it },
                newestFirst = newestFirst,
                onSortToggle = { newestFirst = !newestFirst },
                onClearFilters = {
                    searchQuery = ""
                    dateFilter = ""
                    monthFilter = ""
                    yearFilter = ""
                }
            )

            if (activeParty == null) {
                val filteredParties = hydParties.filter {
                    searchQuery.isBlank() || it.name.contains(searchQuery.trim(), ignoreCase = true)
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "हैदराबाद कंपनी पार्टियां (${filteredParties.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = HaweliNavyBlue
                    )
                    AdminOnlySection(accessRole) {
                        Button(
                            onClick = {
                                editingParty = null
                                showPartyDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                        ) {
                            Icon(Icons.Default.PersonAdd, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("पार्टी जोड़ें")
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (filteredParties.isEmpty()) {
                        item {
                            Text(
                                text = "हैदराबाद कंपनी में कोई पार्टी दर्ज नहीं है।",
                                modifier = Modifier.padding(16.dp),
                                color = Color.Gray
                            )
                        }
                    }
                    items(filteredParties, key = { it.id }) { party ->
                        PartySummaryCard(
                            party = party,
                            accessRole = accessRole,
                            onClick = { selectedParty = party },
                            onEdit = {
                                editingParty = party
                                showPartyDialog = true
                            },
                            onDelete = { partyToDelete = party }
                        )
                    }
                }
            } else {
                val entriesRaw = allEntries.filter { e ->
                    e.partyId == activeParty.id &&
                        (searchQuery.isBlank() || e.date.contains(searchQuery.trim())) &&
                        (dateFilter.isBlank() || e.date == dateFilter.trim()) &&
                        (monthFilter.isBlank() || e.monthYear == monthFilter.trim()) &&
                        (yearFilter.isBlank() || e.date.endsWith(yearFilter.trim()))
                }
                val entries = if (newestFirst) {
                    entriesRaw.sortedWith(compareByDescending<HyderabadEntry> { it.dateEpoch }.thenByDescending { it.createdAt })
                } else {
                    entriesRaw.sortedWith(compareBy<HyderabadEntry> { it.dateEpoch }.thenBy { it.createdAt })
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = HaweliSurfaceLight),
                    border = BorderStroke(1.5.dp, HaweliDarkGreen)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "पार्टी का नाम: ${activeParty.name}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                color = HaweliNavyBlue
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            BalanceBadge(
                                balanceAmount = activeParty.currentBalance,
                                balanceStatusLabel = activeParty.balanceStatus
                            )
                        }
                        AdminOnlySection(accessRole) {
                            Button(
                                onClick = {
                                    editingEntry = null
                                    showEntryDialog = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("नई एंट्री")
                            }
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (entries.isEmpty()) {
                        item {
                            Text(
                                text = "इस पार्टी के लिए कोई हिसाब एंट्री दर्ज नहीं है।",
                                modifier = Modifier.padding(16.dp),
                                color = Color.Gray
                            )
                        }
                    }
                    items(entries, key = { it.id }) { entry ->
                        HyderabadEntryCard(
                            entry = entry,
                            accessRole = accessRole,
                            onEdit = {
                                editingEntry = entry
                                showEntryDialog = true
                            },
                            onDelete = { entryToDelete = entry }
                        )
                    }
                }
            }
        }
    }

    if (showPartyDialog) {
        var partyName by remember(editingParty) { mutableStateOf(editingParty?.name ?: "") }
        var openingBal by remember(editingParty) { mutableStateOf(editingParty?.openingBalance ?: "0.00") }

        AlertDialog(
            onDismissRequest = { showPartyDialog = false },
            title = { Text(if (editingParty == null) "हैदराबाद कंपनी पार्टी जोड़ें" else "पार्टी का नाम बदलें") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = partyName,
                        onValueChange = { partyName = it },
                        label = { Text("पार्टी का नाम") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    HindiDecimalField(
                        value = openingBal,
                        onValueChange = { openingBal = it },
                        label = "प्रारंभिक (पिछला) बैलेंस (₹)",
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (partyName.isNotBlank()) {
                            viewModel.repository.saveParty(
                                module = "HYDERABAD",
                                name = partyName,
                                openingBalance = openingBal,
                                existingId = editingParty?.id
                            )
                            showPartyDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                ) {
                    Text("सहेजें", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showPartyDialog = false }) { Text("रद्द करें") }
            }
        )
    }

    partyToDelete?.let { party ->
        ConfirmDeleteDialog(
            message = "क्या आप हैदराबाद कंपनी पार्टी '${party.name}' को हटाना चाहते हैं?",
            onConfirm = { viewModel.repository.deleteParty(party) },
            onDismiss = { partyToDelete = null }
        )
    }

    if (showEntryDialog && activeParty != null) {
        HyderabadEntryFormDialog(
            party = activeParty,
            initialEntry = editingEntry,
            onDismiss = { showEntryDialog = false },
            onSave = { draft ->
                viewModel.repository.saveHyderabadEntry(activeParty, draft)
                showEntryDialog = false
            }
        )
    }

    entryToDelete?.let { entry ->
        if (activeParty != null) {
            ConfirmDeleteDialog(
                message = "क्या आप तारीख ${entry.date} की एंट्री को हटाना चाहते हैं?",
                onConfirm = { viewModel.repository.deleteHyderabadEntry(activeParty, entry.id) },
                onDismiss = { entryToDelete = null }
            )
        }
    }
}

@Composable
private fun HyderabadEntryCard(
    entry: HyderabadEntry,
    accessRole: AccessRole,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, HaweliCardBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "1. तारीख: ${entry.date}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = HaweliNavyBlue
                )
                AdminOnlySection(accessRole) {
                    Row {
                        IconButton(onClick = onEdit) {
                            Icon(Icons.Default.Edit, contentDescription = "बदलें", tint = HaweliNavyBlue)
                        }
                        IconButton(onClick = onDelete) {
                            Icon(Icons.Default.Delete, contentDescription = "हटाएं", tint = HaweliPaymentRed)
                        }
                    }
                }
            }

            Divider(color = HaweliCardBorder)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("2. कुल बड़ा माल: ${entry.totalBadaMaalCount}", fontSize = 14.sp)
                Text("3. बड़ा वजन: ${entry.badaMaalWeight}", fontSize = 14.sp)
                Text("4. बड़ा रेट: ₹${entry.badaMaalRate}", fontSize = 14.sp)
            }
            Text(
                text = "5. बड़ा माल की रकम: ${DateAndFormatUtils.formatIndianCurrency(entry.badaMaalAmount)}",
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("6. कुल वील माल: ${entry.totalVeelMaalCount}", fontSize = 14.sp)
                Text("7. वील वजन: ${entry.veelMaalWeight}", fontSize = 14.sp)
                Text("8. वील रेट: ₹${entry.veelMaalRate}", fontSize = 14.sp)
            }
            Text(
                text = "9. वील माल की रकम: ${DateAndFormatUtils.formatIndianCurrency(entry.veelMaalAmount)}",
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    text = "10. दोनों की कुल रकम: ${DateAndFormatUtils.formatIndianCurrency(entry.totalCombinedAmount)}",
                    fontWeight = FontWeight.Bold,
                    color = HaweliDarkGreen
                )
                Text(
                    text = "11. पिछला बैलेंस: ${DateAndFormatUtils.formatIndianCurrency(entry.previousBalance)}",
                    fontWeight = FontWeight.SemiBold
                )
            }

            // 12 & 13: प्राप्त भुगतान & भुगतान की तारीख in RED colour
            RedPaymentRow(
                label = "12-13. प्राप्त भुगतान",
                paymentAmount = entry.receivedPayment,
                paymentDate = entry.paymentDate
            )

            // 14: बाकी बैलेंस (बाकी आना / एडवांस / हिसाब बराबर)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("14. बाकी बैलेंस:", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                BalanceBadge(
                    balanceAmount = entry.remainingBalance,
                    balanceStatusLabel = entry.balanceStatus
                )
            }
        }
    }
}

@Composable
private fun HyderabadEntryFormDialog(
    party: PartyRecord,
    initialEntry: HyderabadEntry?,
    onDismiss: () -> Unit,
    onSave: (HyderabadEntry) -> Unit
) {
    var date by remember { mutableStateOf(initialEntry?.date ?: DateAndFormatUtils.todayFormatted()) }
    var badaCount by remember { mutableStateOf(initialEntry?.totalBadaMaalCount ?: "0") }
    var badaWeight by remember { mutableStateOf(initialEntry?.badaMaalWeight ?: "0.00") }
    var badaRate by remember { mutableStateOf(initialEntry?.badaMaalRate ?: "0.00") }
    var veelCount by remember { mutableStateOf(initialEntry?.totalVeelMaalCount ?: "0") }
    var veelWeight by remember { mutableStateOf(initialEntry?.veelMaalWeight ?: "0.00") }
    var veelRate by remember { mutableStateOf(initialEntry?.veelMaalRate ?: "0.00") }
    var receivedPayment by remember { mutableStateOf(initialEntry?.receivedPayment ?: "0.00") }
    var paymentDate by remember { mutableStateOf(initialEntry?.paymentDate ?: DateAndFormatUtils.todayFormatted()) }

    val badaAmt = AccountingCalculator.multiply(badaWeight, badaRate)
    val veelAmt = AccountingCalculator.multiply(veelWeight, veelRate)
    val totalAmt = badaAmt.add(veelAmt)
    val prevBal = initialEntry?.previousBalance ?: party.currentBalance
    val closingBal = AccountingCalculator.calculateClosingBalance(
        previousBalance = prevBal,
        newCharges = totalAmt.toPlainString(),
        payment = receivedPayment
    )
    val status = AccountingCalculator.resolveReceivableStatus(closingBal)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialEntry == null) "हैदराबाद कंपनी नई एंट्री (${party.name})" else "हैदराबाद एंट्री संपादित करें",
                fontWeight = FontWeight.Bold,
                color = HaweliNavyBlue
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it },
                    label = { Text("1. तारीख (DD-MM-YYYY)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HindiDecimalField(
                        value = badaCount,
                        onValueChange = { badaCount = it },
                        label = "2. कुल बड़ा माल",
                        modifier = Modifier.weight(1f)
                    )
                    HindiDecimalField(
                        value = badaWeight,
                        onValueChange = { badaWeight = it },
                        label = "3. बड़ा माल का वजन",
                        modifier = Modifier.weight(1f)
                    )
                }
                HindiDecimalField(
                    value = badaRate,
                    onValueChange = { badaRate = it },
                    label = "4. बड़ा माल का रेट (₹)",
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "5. बड़ा माल की रकम: ${DateAndFormatUtils.formatIndianCurrency(badaAmt.toPlainString())}",
                    fontWeight = FontWeight.SemiBold,
                    color = HaweliDarkGreen
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HindiDecimalField(
                        value = veelCount,
                        onValueChange = { veelCount = it },
                        label = "6. कुल वील माल",
                        modifier = Modifier.weight(1f)
                    )
                    HindiDecimalField(
                        value = veelWeight,
                        onValueChange = { veelWeight = it },
                        label = "7. वील माल का वजन",
                        modifier = Modifier.weight(1f)
                    )
                }
                HindiDecimalField(
                    value = veelRate,
                    onValueChange = { veelRate = it },
                    label = "8. वील माल का रेट (₹)",
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "9. वील माल की रकम: ${DateAndFormatUtils.formatIndianCurrency(veelAmt.toPlainString())}",
                    fontWeight = FontWeight.SemiBold,
                    color = HaweliDarkGreen
                )

                Text(
                    text = "10. दोनों की कुल रकम: ${DateAndFormatUtils.formatIndianCurrency(totalAmt.toPlainString())}",
                    fontWeight = FontWeight.Bold,
                    color = HaweliNavyBlue
                )
                Text(
                    text = "11. पिछला बैलेंस: ${DateAndFormatUtils.formatIndianCurrency(prevBal)}",
                    fontWeight = FontWeight.SemiBold
                )

                HindiDecimalField(
                    value = receivedPayment,
                    onValueChange = { receivedPayment = it },
                    label = "12. प्राप्त भुगतान (₹ - लाल रंग में दिखेगा)",
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = paymentDate,
                    onValueChange = { paymentDate = it },
                    label = { Text("13. भुगतान की तारीख (DD-MM-YYYY)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                BalanceBadge(
                    balanceAmount = closingBal.toPlainString(),
                    balanceStatusLabel = "14. ${status.hindiLabel}"
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        HyderabadEntry(
                            id = initialEntry?.id ?: "",
                            date = date,
                            totalBadaMaalCount = badaCount,
                            badaMaalWeight = badaWeight,
                            badaMaalRate = badaRate,
                            totalVeelMaalCount = veelCount,
                            veelMaalWeight = veelWeight,
                            veelMaalRate = veelRate,
                            receivedPayment = receivedPayment,
                            paymentDate = paymentDate,
                            createdAt = initialEntry?.createdAt ?: System.currentTimeMillis()
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
            ) {
                Text("सहेजें", color = Color.White)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("रद्द करें") }
        }
    )
}
