package com.haweli.firebase

import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.database.ServerValue
import com.haweli.database.DatabasePaths
import com.haweli.models.AccessRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

/**
 * Manages Viewer Mode (Firebase Anonymous Authentication) and Admin Mode
 * (Firebase Email/Password + Cloud Functions Custom Claims verification + Mandatory First-Login Password Change).
 * No plaintext admin password is ever hardcoded in the APK or saved in the database.
 */
class AuthManager {

    companion object {
        private const val ADMIN_CANONICAL_USERNAME = "Haweli"
        private const val ADMIN_AUTH_EMAIL = "haweli@haweli-accounting.local"
    }

    private val _accessRole = MutableStateFlow(AccessRole.VIEWER)
    val accessRole: StateFlow<AccessRole> = _accessRole.asStateFlow()

    private val _mustChangePassword = MutableStateFlow(false)
    val mustChangePassword: StateFlow<Boolean> = _mustChangePassword.asStateFlow()

    private val _currentUserUid = MutableStateFlow("")
    val currentUserUid: StateFlow<String> = _currentUserUid.asStateFlow()

    private val _authStatusMessage = MutableStateFlow("व्यूअर मोड सक्रिय")
    val authStatusMessage: StateFlow<String> = _authStatusMessage.asStateFlow()

    /**
     * Called on application startup.
     * - If an admin session is already active, verifies admin claims and role.
     * - Otherwise signs in anonymously so the Viewer can immediately read live Firebase data
     *   under authenticated security rules (`auth != null`).
     */
    suspend fun initializeSession() {
        try {
            val currentUser = FirebaseClient.auth.currentUser
            if (currentUser != null && !currentUser.isAnonymous) {
                _currentUserUid.value = currentUser.uid
                refreshAdminRoleState(currentUser.uid)
            } else {
                ensureViewerAnonymousSignIn()
            }
        } catch (e: Exception) {
            _accessRole.value = AccessRole.VIEWER
            _authStatusMessage.value = "ऑफ़लाइन व्यूअर मोड सक्रिय"
        }
    }

    suspend fun ensureViewerAnonymousSignIn() {
        try {
            val current = FirebaseClient.auth.currentUser
            if (current == null) {
                val result = FirebaseClient.auth.signInAnonymously().await()
                _currentUserUid.value = result.user?.uid ?: ""
            } else {
                _currentUserUid.value = current.uid
            }
            _accessRole.value = AccessRole.VIEWER
            _mustChangePassword.value = false
            _authStatusMessage.value = "व्यूअर मोड (केवल देखने की अनुमति)"
        } catch (e: Exception) {
            _accessRole.value = AccessRole.VIEWER
            _mustChangePassword.value = false
            _authStatusMessage.value = "व्यूअर मोड (स्थानीय कैश)"
        }
    }

    /**
     * Admin login using Username ("Haweli") and password via Firebase Authentication
     * and Cloud Functions role verification (`verifyAdminRole`).
     */
    suspend fun loginAsAdmin(usernameInput: String, passwordInput: String): Result<Boolean> {
        val cleanUsername = usernameInput.trim()
        val cleanPassword = passwordInput.trim()

        if (!cleanUsername.equals(ADMIN_CANONICAL_USERNAME, ignoreCase = true)) {
            return Result.failure(Exception("अमान्य एडमिन यूज़रनेम। कृपया 'Haweli' दर्ज करें।"))
        }
        if (cleanPassword.isEmpty()) {
            return Result.failure(Exception("कृपया पासवर्ड दर्ज करें।"))
        }

        return try {
            // Ensure initial admin provisioning on backend if first run
            try {
                FirebaseClient.functions
                    .getHttpsCallable("provisionInitialAdmin")
                    .call()
                    .await()
            } catch (_: Exception) {
                // Provisioning function may already have run or be unreachable offline
            }

            val authResult = FirebaseClient.auth
                .signInWithEmailAndPassword(ADMIN_AUTH_EMAIL, cleanPassword)
                .await()

            val user = authResult.user
                ?: return Result.failure(Exception("एडमिन प्रमाणीकरण विफल रहा।"))

            _currentUserUid.value = user.uid

            // Verify admin claim via Cloud Function & refresh ID token
            try {
                FirebaseClient.functions
                    .getHttpsCallable("verifyAdminRole")
                    .call()
                    .await()
            } catch (_: Exception) {
                // Fallback to existing token claim / users node check
            }

            val tokenResult = user.getIdToken(true).await()
            val claimAdmin = tokenResult.claims["admin"] as? Boolean ?: false
            val claimMustChange = tokenResult.claims["mustChangePassword"] as? Boolean

            val userSnap = FirebaseClient.ref("${DatabasePaths.USERS}/${user.uid}").get().await()
            val dbRole = userSnap.child("role").getValue(String::class.java)
            val dbMustChange = userSnap.child("mustChangePassword").getValue(Boolean::class.java)

            if (!claimAdmin && dbRole != AccessRole.ADMIN.name && user.email != ADMIN_AUTH_EMAIL) {
                FirebaseClient.auth.signOut()
                ensureViewerAnonymousSignIn()
                return Result.failure(Exception("इस खाते को एडमिन अधिकार प्राप्त नहीं हैं।"))
            }

            val requirePasswordChange = claimMustChange ?: dbMustChange ?: false
            _accessRole.value = AccessRole.ADMIN
            _mustChangePassword.value = requirePasswordChange
            _authStatusMessage.value = if (requirePasswordChange) {
                "प्रथम लॉगिन: कृपया सुरक्षा के लिए तुरंत अपना पासवर्ड बदलें"
            } else {
                "एडमिन मोड सक्रिय (Haweli)"
            }

            Result.success(requirePasswordChange)
        } catch (e: Exception) {
            Result.failure(
                Exception("लॉगिन विफल: कृपया यूज़रनेम/पासवर्ड या इंटरनेट कनेक्शन जांचें। (${e.localizedMessage ?: ""})")
            )
        }
    }

    private suspend fun refreshAdminRoleState(uid: String) {
        try {
            val user = FirebaseClient.auth.currentUser ?: return
            val tokenResult = user.getIdToken(false).await()
            val claimAdmin = tokenResult.claims["admin"] as? Boolean ?: false
            val claimMustChange = tokenResult.claims["mustChangePassword"] as? Boolean

            val snap = FirebaseClient.ref("${DatabasePaths.USERS}/$uid").get().await()
            val dbRole = snap.child("role").getValue(String::class.java)
            val dbMustChange = snap.child("mustChangePassword").getValue(Boolean::class.java)

            if (claimAdmin || dbRole == AccessRole.ADMIN.name || user.email == ADMIN_AUTH_EMAIL) {
                _accessRole.value = AccessRole.ADMIN
                _mustChangePassword.value = claimMustChange ?: dbMustChange ?: false
                _authStatusMessage.value = "एडमिन मोड सक्रिय (Haweli)"
            } else {
                ensureViewerAnonymousSignIn()
            }
        } catch (_: Exception) {
            // If offline and already signed in with admin email, preserve cached admin session
            val user = FirebaseClient.auth.currentUser
            if (user != null && user.email == ADMIN_AUTH_EMAIL) {
                _accessRole.value = AccessRole.ADMIN
                _authStatusMessage.value = "एडमिन मोड (ऑफ़लाइन कैश)"
            } else {
                _accessRole.value = AccessRole.VIEWER
            }
        }
    }

    /**
     * Changes the admin password securely through Firebase Authentication re-authentication
     * and marks `mustChangePassword = false` via Cloud Function and `/haweli/users/{uid}`.
     */
    suspend fun changeAdminPassword(
        currentPassword: String,
        newPassword: String,
        confirmPassword: String
    ): Result<Unit> {
        if (_accessRole.value != AccessRole.ADMIN) {
            return Result.failure(Exception("केवल एडमिन पासवर्ड बदल सकता है।"))
        }
        if (newPassword.length < 6) {
            return Result.failure(Exception("नया पासवर्ड कम से कम 6 अक्षरों का होना चाहिए।"))
        }
        if (newPassword != confirmPassword) {
            return Result.failure(Exception("नया पासवर्ड और पुष्टि पासवर्ड मेल नहीं खाते।"))
        }
        if (newPassword.equals("Haweli", ignoreCase = true)) {
            return Result.failure(Exception("सुरक्षा के लिए नया पासवर्ड प्रारंभिक 'Haweli' से भिन्न होना चाहिए।"))
        }

        return try {
            val user = FirebaseClient.auth.currentUser
                ?: return Result.failure(Exception("कोई सक्रिय एडमिन सत्र नहीं मिला।"))

            val credential = EmailAuthProvider.getCredential(ADMIN_AUTH_EMAIL, currentPassword.trim())
            user.reauthenticate(credential).await()
            user.updatePassword(newPassword.trim()).await()

            try {
                FirebaseClient.functions
                    .getHttpsCallable("completeInitialPasswordChange")
                    .call()
                    .await()
            } catch (_: Exception) {
                // Update user node directly if Cloud Function is unreachable
            }

            FirebaseClient.ref("${DatabasePaths.USERS}/${user.uid}").updateChildren(
                mapOf(
                    "mustChangePassword" to false,
                    "updatedAt" to ServerValue.TIMESTAMP
                )
            ).await()

            user.getIdToken(true).await()
            _mustChangePassword.value = false
            _authStatusMessage.value = "एडमिन मोड सक्रिय (पासवर्ड सुरक्षित रूप से अपडेट किया गया)"
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(Exception("पासवर्ड बदलने में त्रुटि: ${e.localizedMessage ?: "वर्तमान पासवर्ड जांचें"}"))
        }
    }

    /**
     * Logs out of Admin Mode and immediately transitions back to read-only Viewer Mode.
     */
    suspend fun logoutAdminToViewer() {
        try {
            FirebaseClient.auth.signOut()
        } catch (_: Exception) {
        }
        ensureViewerAnonymousSignIn()
    }
}
