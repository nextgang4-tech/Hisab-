package com.haweli.firebase

import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.functions.FirebaseFunctions
import com.haweli.database.DatabasePaths
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * Singleton wrapper configuring Firebase Realtime Database with offline persistence,
 * disk cache size, and realtime connection state monitoring for https://haweli123-default-rtdb.firebaseio.com/.
 */
object FirebaseClient {

    @Volatile
    private var persistenceInitialized = false

    val database: FirebaseDatabase by lazy {
        val db = FirebaseDatabase.getInstance(DatabasePaths.DATABASE_URL)
        if (!persistenceInitialized) {
            try {
                db.setPersistenceEnabled(true)
                db.setPersistenceCacheSizeBytes(50L * 1024L * 1024L) // 50 MB offline cache
                db.getReference(DatabasePaths.ROOT).keepSynced(true)
            } catch (_: Exception) {
                // Already enabled on warm restart
            }
            persistenceInitialized = true
        }
        db
    }

    val auth: FirebaseAuth by lazy {
        FirebaseAuth.getInstance()
    }

    val functions: FirebaseFunctions by lazy {
        FirebaseFunctions.getInstance()
    }

    fun rootRef(): DatabaseReference = database.getReference(DatabasePaths.ROOT)

    fun ref(path: String): DatabaseReference = database.getReference(path)

    /**
     * Emits true when connected to Firebase Realtime Database servers, false when offline.
     */
    fun observeConnectionStatus(): Flow<Boolean> = callbackFlow {
        val connectedRef = try {
            database.getReference(".info/connected")
        } catch (e: Exception) {
            trySend(false)
            close()
            return@callbackFlow
        }

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val connected = snapshot.getValue(Boolean::class.java) ?: false
                trySend(connected)
            }

            override fun onCancelled(error: DatabaseError) {
                trySend(false)
            }
        }
        connectedRef.addValueEventListener(listener)
        awaitClose { connectedRef.removeEventListener(listener) }
    }
}
