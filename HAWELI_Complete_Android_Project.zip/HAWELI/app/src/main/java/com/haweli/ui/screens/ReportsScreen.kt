package com.haweli.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haweli.HaweliViewModel
import com.haweli.calculations.AccountingCalculator
import com.haweli.models.*
import com.haweli.pdf.HaweliPdfGenerator
import com.haweli.pdf.PdfReportDocumentData
import com.haweli.ui.components.HaweliTopBar
import com.haweli.ui.theme.*
import com.haweli.utils.DateAndFormatUtils
import java.io.File
import java.math.BigDecimal

enum class ReportTypeOption(val hindiTitle: String) {
    FOUR_PC_PARTY("1. 4PC पार्टी रिपोर्ट"),
    CITY_WISE("2. शहर-वार (City-wise) हिसाब रिपोर्ट"),
    PARTY_WISE("3. व्यक्तिगत पार्टी-वार (Party-wise) रिपोर्ट"),
    HYDERABAD_COMPANY("4. हैदराबाद कंपनी रिपोर्ट"),
    CHAMDA_DAILY("5. चमड़ा दैनिक आवक रिपोर्ट"),
    CHAMDA_MONTHLY("6. चमड़ा मासिक आवक व स्टॉक रिपोर्ट"),
    CHAMDA_SALES("7. चमड़ा बिक्री रिपोर्ट"),
    KENA("8. केना हिसाब रिपोर्ट"),
    POTLI("9. पोटली हिसाब रिपोर्ट"),
    VEHICLE_RECORDS("10. ओबाद से हैदराबाद गाड़ी रिपोर्ट"),
    MONTHLY_OVERALL("11. मासिक संपूर्ण रिपोर्ट"),
    YEARLY_OVERALL("12. वार्षिक संपूर्ण रिपोर्ट"),
    TOTAL_AANA_DENA("13. कुल आना और कुल देना रिपोर्ट")
}

/**
 * 10. REPORTS AND PDF SYSTEM SCREEN (रिपोर्ट एवं पीडीएफ केंद्र)
 * Generates all 13 required Hindi PDF reports with:
 * - Date range filter (प्रारंभ तारीख से अंतिम तारीख)
 * - Month / Year filter
 * - Individual party or city selector
 * - Save PDF on phone, Share via WhatsApp, Share via other apps, and Print PDF
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    viewModel: HaweliViewModel,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    val isConnected by viewModel.isConnected.collectAsState()
    val pendingWrites by viewModel.pendingWriteCount.collectAsState()
    val accessRole by viewModel.accessRole.collectAsState()

    val cities by viewModel.cities.collectAsState()
    val parties by viewModel.parties.collectAsState()
    val fourPcEntries by viewModel.fourPcEntries.collectAsState()
    val hyderabadEntries by viewModel.hyderabadEntries.collectAsState()
    val chamdaOpening by viewModel.chamdaOpeningStock.collectAsState()
    val chamdaAwak by viewModel.chamdaAwakEntries.collectAsState()
    val chamdaBikri by viewModel.chamdaBikriEntries.collectAsState()
    val kenaEntries by viewModel.kenaEntries.collectAsState()
    val potliEntries by viewModel.potliEntries.collectAsState()
    val vehicleEntries by viewModel.vehicleEntries.collectAsState()
    val dashboardTotals by viewModel.dashboardTotals.collectAsState()
    val savedReports by viewModel.reports.collectAsState()

    var selectedReportType by remember { mutableStateOf(ReportTypeOption.TOTAL_AANA_DENA) }
    var reportDropdownExpanded by remember { mutableStateOf(false) }

    var selectedPartyId by remember { mutableStateOf("") }
    var partyDropdownExpanded by remember { mutableStateOf(false) }

    var selectedCityId by remember { mutableStateOf("") }
    var cityDropdownExpanded by remember { mutableStateOf(false) }

    var startDateFilter by remember { mutableStateOf("") }
    var endDateFilter by remember { mutableStateOf("") }
    var monthYearFilter by remember { mutableStateOf(DateAndFormatUtils.currentMonthYear()) }
    var yearFilter by remember { mutableStateOf(DateAndFormatUtils.currentYear()) }

    var lastGeneratedFile by remember { mutableStateOf<File?>(null) }
    var lastGeneratedTitle by remember { mutableStateOf("") }

    fun buildReportData(): PdfReportDocumentData {
        val startEpoch = if (startDateFilter.isNotBlank()) DateAndFormatUtils.parseDateToEpoch(startDateFilter) else Long.MIN_VALUE
        val endEpoch = if (endDateFilter.isNotBlank()) DateAndFormatUtils.parseDateToEpoch(endDateFilter) + 86_399_000L else Long.MAX_VALUE
        val rangeLabel = when {
            startDateFilter.isNotBlank() || endDateFilter.isNotBlank() ->
                "${startDateFilter.ifBlank { "शुरू" }} से ${endDateFilter.ifBlank { "आज" }}"
            monthYearFilter.isNotBlank() -> "महीना: $monthYearFilter"
            yearFilter.isNotBlank() -> "वर्ष: $yearFilter"
            else -> "संपूर्ण अवधि"
        }

        val chosenParty = parties.find { it.id == selectedPartyId }
        val chosenCity = cities.find { it.id == selectedCityId }

        return when (selectedReportType) {
            ReportTypeOption.FOUR_PC_PARTY -> {
                val list = fourPcEntries.filter { e ->
                    e.dateEpoch in startEpoch..endEpoch &&
                        (selectedPartyId.isBlank() || e.partyId == selectedPartyId) &&
                        (monthYearFilter.isBlank() || e.monthYear == monthYearFilter)
                }
                val totalAmt = list.fold(BigDecimal.ZERO) { a, b -> a.add(AccountingCalculator.parseDecimal(b.totalCombinedAmount)) }
                val totalPaid = list.fold(BigDecimal.ZERO) { a, b -> a.add(AccountingCalculator.parseDecimal(b.paymentAmount)) }
                val finalBal = chosenParty?.currentBalance ?: dashboardTotals.fourPcPayable
                PdfReportDocumentData(
                    reportTitleHindi = "4PC पार्टी हिसाब रिपोर्ट",
                    subtitleHindi = "बड़ा व वील माल खरीद एवं भुगतान विवरण",
                    partyOrSectionName = chosenParty?.name ?: "सभी 4PC पार्टियां",
                    dateRangeLabel = rangeLabel,
                    previousBalance = chosenParty?.openingBalance ?: "0.00",
                    totalAmount = totalAmt.toPlainString(),
                    totalPaidOrReceived = totalPaid.toPlainString(),
                    finalBalance = finalBal,
                    finalBalanceStatus = chosenParty?.balanceStatus ?: "बाकी देना",
                    tableHeaders = listOf("तारीख", "पार्टी", "बड़ा वजन/रकम", "वील वजन/रकम", "कुल रकम", "भुगतान (लाल)", "बाकी बैलेंस"),
                    tableRows = list.map {
                        listOf(
                            it.date,
                            it.partyName,
                            "${it.badaMaalWeight}/${it.badaMaalAmount}",
                            "${it.veelMaalWeight}/${it.veelMaalAmount}",
                            it.totalCombinedAmount,
                            "${it.paymentAmount} (${it.paymentDate})",
                            "${it.remainingBalance} (${it.balanceStatus})"
                        )
                    },
                    paymentColumnIndex = 5
                )
            }

            ReportTypeOption.CITY_WISE -> {
                val cityParties = parties.filter {
                    it.module == "FOUR_PC" && (selectedCityId.isBlank() || it.cityId == selectedCityId)
                }
                val totalBal = cityParties.fold(BigDecimal.ZERO) { a, b -> a.add(AccountingCalculator.parseDecimal(b.currentBalance)) }
                PdfReportDocumentData(
                    reportTitleHindi = "शहर-वार (City-wise) पार्टी बैलेंस रिपोर्ट",
                    subtitleHindi = "शहर के अनुसार सभी पार्टियों का वर्तमान बैलेंस",
                    partyOrSectionName = chosenCity?.name ?: "सभी शहर",
                    dateRangeLabel = rangeLabel,
                    previousBalance = "0.00",
                    totalAmount = totalBal.toPlainString(),
                    totalPaidOrReceived = "0.00",
                    finalBalance = totalBal.toPlainString(),
                    finalBalanceStatus = AccountingCalculator.resolvePayableStatus(totalBal).hindiLabel,
                    tableHeaders = listOf("शहर का नाम", "पार्टी का नाम", "प्रारंभिक बैलेंस", "वर्तमान बाकी बैलेंस", "स्थिति"),
                    tableRows = cityParties.map {
                        listOf(it.cityName, it.name, it.openingBalance, it.currentBalance, it.balanceStatus)
                    }
                )
            }

            ReportTypeOption.PARTY_WISE -> {
                val target = chosenParty ?: parties.firstOrNull()
                val pName = target?.name ?: "कोई पार्टी चयनित नहीं"
                val mod = target?.module ?: ""
                val rows = when (mod) {
                    "FOUR_PC" -> fourPcEntries.filter { it.partyId == target?.id }.map {
                        listOf(it.date, "4PC पार्टी", it.totalCombinedAmount, it.paymentAmount, it.remainingBalance, it.balanceStatus)
                    }
                    "HYDERABAD" -> hyderabadEntries.filter { it.partyId == target?.id }.map {
                        listOf(it.date, "हैदराबाद", it.totalCombinedAmount, it.receivedPayment, it.remainingBalance, it.balanceStatus)
                    }
                    "CHAMDA_SALES" -> chamdaBikri.filter { it.partyId == target?.id }.map {
                        listOf(it.date, "चमड़ा बिक्री", it.totalSaleAmount, it.receivedPayment, it.remainingBalance, it.balanceStatus)
                    }
                    "KENA" -> kenaEntries.filter { it.partyId == target?.id }.map {
                        listOf(it.date, "केना", it.totalAmount, it.receivedPayment, it.remainingBalance, it.balanceStatus)
                    }
                    "POTLI" -> potliEntries.filter { it.partyId == target?.id }.map {
                        listOf(it.date, "पोटली", it.totalAmount, it.receivedPayment, it.remainingBalance, it.balanceStatus)
                    }
                    else -> emptyList()
                }
                PdfReportDocumentData(
                    reportTitleHindi = "व्यक्तिगत पार्टी खाता रिपोर्ट",
                    subtitleHindi = "पार्टी का संपूर्ण लेनदेन इतिहास",
                    partyOrSectionName = pName,
                    dateRangeLabel = rangeLabel,
                    previousBalance = target?.openingBalance ?: "0.00",
                    totalAmount = rows.fold(BigDecimal.ZERO) { a, r -> a.add(AccountingCalculator.parseDecimal(r.getOrNull(2))) }.toPlainString(),
                    totalPaidOrReceived = rows.fold(BigDecimal.ZERO) { a, r -> a.add(AccountingCalculator.parseDecimal(r.getOrNull(3))) }.toPlainString(),
                    finalBalance = target?.currentBalance ?: "0.00",
                    finalBalanceStatus = target?.balanceStatus ?: "हिसाब बराबर",
                    tableHeaders = listOf("तारीख", "विभाग", "कुल रकम", "भुगतान (लाल)", "बाकी बैलेंस", "स्थिति"),
                    tableRows = rows,
                    paymentColumnIndex = 3
                )
            }

            ReportTypeOption.HYDERABAD_COMPANY -> {
                val list = hyderabadEntries.filter { e ->
                    e.dateEpoch in startEpoch..endEpoch &&
                        (selectedPartyId.isBlank() || e.partyId == selectedPartyId) &&
                        (monthYearFilter.isBlank() || e.monthYear == monthYearFilter)
                }
                val totalAmt = list.fold(BigDecimal.ZERO) { a, b -> a.add(AccountingCalculator.parseDecimal(b.totalCombinedAmount)) }
                val totalRec = list.fold(BigDecimal.ZERO) { a, b -> a.add(AccountingCalculator.parseDecimal(b.receivedPayment)) }
                PdfReportDocumentData(
                    reportTitleHindi = "हैदराबाद कंपनी हिसाब रिपोर्ट",
                    subtitleHindi = "बड़ा व वील माल बिक्री एवं प्राप्त भुगतान",
                    partyOrSectionName = chosenParty?.name ?: "सभी हैदराबाद पार्टियां",
                    dateRangeLabel = rangeLabel,
                    previousBalance = chosenParty?.openingBalance ?: "0.00",
                    totalAmount = totalAmt.toPlainString(),
                    totalPaidOrReceived = totalRec.toPlainString(),
                    finalBalance = chosenParty?.currentBalance ?: dashboardTotals.hyderabadReceivable,
                    finalBalanceStatus = chosenParty?.balanceStatus ?: "बाकी आना",
                    tableHeaders = listOf("तारीख", "पार्टी", "बड़ा रकम", "वील रकम", "कुल रकम", "प्राप्त भुगतान", "बाकी बैलेंस"),
                    tableRows = list.map {
                        listOf(
                            it.date,
                            it.partyName,
                            it.badaMaalAmount,
                            it.veelMaalAmount,
                            it.totalCombinedAmount,
                            "${it.receivedPayment} (${it.paymentDate})",
                            "${it.remainingBalance} (${it.balanceStatus})"
                        )
                    },
                    paymentColumnIndex = 5
                )
            }

            ReportTypeOption.CHAMDA_DAILY, ReportTypeOption.CHAMDA_MONTHLY -> {
                val list = chamdaAwak.filter { e ->
                    e.dateEpoch in startEpoch..endEpoch &&
                        (monthYearFilter.isBlank() || e.monthYear == monthYearFilter)
                }
                val stockSum = AccountingCalculator.calculateChamdaStockSummary(
                    chamdaOpening,
                    chamdaAwak,
                    chamdaBikri,
                    monthYearFilter.ifBlank { DateAndFormatUtils.currentMonthYear() }
                )
                PdfReportDocumentData(
                    reportTitleHindi = selectedReportType.hindiTitle,
                    subtitleHindi = "चमड़ा आवक एवं बचा हुआ स्टॉक विवरण",
                    partyOrSectionName = "चमड़ा आवक विभाग",
                    dateRangeLabel = rangeLabel,
                    previousBalance = "0.00",
                    totalAmount = stockSum.monthTotalWeight,
                    totalPaidOrReceived = "0.00",
                    finalBalance = stockSum.closingBadaStock,
                    finalBalanceStatus = "बचा बड़ा: ${stockSum.closingBadaStock}, वील: ${stockSum.closingVeelStock}",
                    monthlySummaryLines = listOf(
                        "इस महीने आया बड़ा: ${stockSum.monthBadaAwak}",
                        "आया वील: ${stockSum.monthVeelAwak}",
                        "बिका बड़ा: ${stockSum.monthBadaSold}",
                        "बिका वील: ${stockSum.monthVeelSold}"
                    ),
                    tableHeaders = listOf("तारीख", "बड़ा चमड़ा", "बड़ा वजन", "वील चमड़ा", "वील वजन", "कुल चमड़ा", "कुल वजन"),
                    tableRows = list.map {
                        listOf(
                            it.date,
                            it.badaChamdaCount,
                            it.badaChamdaWeight,
                            it.veelChamdaCount,
                            it.veelChamdaWeight,
                            it.totalChamdaCount,
                            it.totalWeight
                        )
                    }
                )
            }

            ReportTypeOption.CHAMDA_SALES -> {
                val list = chamdaBikri.filter { e ->
                    e.dateEpoch in startEpoch..endEpoch &&
                        (selectedPartyId.isBlank() || e.partyId == selectedPartyId) &&
                        (monthYearFilter.isBlank() || e.monthYear == monthYearFilter)
                }
                val totalSale = list.fold(BigDecimal.ZERO) { a, b -> a.add(AccountingCalculator.parseDecimal(b.totalSaleAmount)) }
                val totalRec = list.fold(BigDecimal.ZERO) { a, b -> a.add(AccountingCalculator.parseDecimal(b.receivedPayment)) }
                PdfReportDocumentData(
                    reportTitleHindi = "चमड़ा बिक्री हिसाब रिपोर्ट",
                    subtitleHindi = "पार्टी-वार चमड़ा बिक्री एवं प्राप्त भुगतान",
                    partyOrSectionName = chosenParty?.name ?: "सभी चमड़ा ग्राहक पार्टियां",
                    dateRangeLabel = rangeLabel,
                    previousBalance = chosenParty?.openingBalance ?: "0.00",
                    totalAmount = totalSale.toPlainString(),
                    totalPaidOrReceived = totalRec.toPlainString(),
                    finalBalance = chosenParty?.currentBalance ?: dashboardTotals.chamdaSalesReceivable,
                    finalBalanceStatus = chosenParty?.balanceStatus ?: "बाकी आना",
                    tableHeaders = listOf("तारीख", "पार्टी", "बड़ा संख्या/रकम", "वील संख्या/रकम", "कुल बिक्री", "प्राप्त भुगतान", "बाकी बैलेंस"),
                    tableRows = list.map {
                        listOf(
                            it.date,
                            it.partyName,
                            "${it.badaChamdaCount}/${it.badaChamdaAmount}",
                            "${it.veelChamdaCount}/${it.veelChamdaAmount}",
                            it.totalSaleAmount,
                            it.receivedPayment,
                            "${it.remainingBalance} (${it.balanceStatus})"
                        )
                    },
                    paymentColumnIndex = 5
                )
            }

            ReportTypeOption.KENA -> {
                val list = kenaEntries.filter { e ->
                    e.dateEpoch in startEpoch..endEpoch &&
                        (selectedPartyId.isBlank() || e.partyId == selectedPartyId) &&
                        (monthYearFilter.isBlank() || e.monthYear == monthYearFilter)
                }
                val totalAmt = list.fold(BigDecimal.ZERO) { a, b -> a.add(AccountingCalculator.parseDecimal(b.totalAmount)) }
                val totalRec = list.fold(BigDecimal.ZERO) { a, b -> a.add(AccountingCalculator.parseDecimal(b.receivedPayment)) }
                PdfReportDocumentData(
                    reportTitleHindi = "केना हिसाब रिपोर्ट",
                    subtitleHindi = "तारीख-वार और पार्टी-वार केना हिसाब",
                    partyOrSectionName = chosenParty?.name ?: "सभी केना पार्टियां",
                    dateRangeLabel = rangeLabel,
                    previousBalance = chosenParty?.openingBalance ?: "0.00",
                    totalAmount = totalAmt.toPlainString(),
                    totalPaidOrReceived = totalRec.toPlainString(),
                    finalBalance = chosenParty?.currentBalance ?: dashboardTotals.kenaReceivable,
                    finalBalanceStatus = chosenParty?.balanceStatus ?: "बाकी आना",
                    tableHeaders = listOf("तारीख", "पार्टी", "कुल केना", "रेट", "कुल रकम", "प्राप्त भुगतान", "बाकी बैलेंस"),
                    tableRows = list.map {
                        listOf(it.date, it.partyName, it.totalKena, it.rate, it.totalAmount, it.receivedPayment, it.remainingBalance)
                    },
                    paymentColumnIndex = 5
                )
            }

            ReportTypeOption.POTLI -> {
                val list = potliEntries.filter { e ->
                    e.dateEpoch in startEpoch..endEpoch &&
                        (selectedPartyId.isBlank() || e.partyId == selectedPartyId) &&
                        (monthYearFilter.isBlank() || e.monthYear == monthYearFilter)
                }
                val totalAmt = list.fold(BigDecimal.ZERO) { a, b -> a.add(AccountingCalculator.parseDecimal(b.totalAmount)) }
                val totalRec = list.fold(BigDecimal.ZERO) { a, b -> a.add(AccountingCalculator.parseDecimal(b.receivedPayment)) }
                PdfReportDocumentData(
                    reportTitleHindi = "पोटली हिसाब रिपोर्ट",
                    subtitleHindi = "तारीख-वार और पार्टी-वार पोटली हिसाब",
                    partyOrSectionName = chosenParty?.name ?: "सभी पोटली पार्टियां",
                    dateRangeLabel = rangeLabel,
                    previousBalance = chosenParty?.openingBalance ?: "0.00",
                    totalAmount = totalAmt.toPlainString(),
                    totalPaidOrReceived = totalRec.toPlainString(),
                    finalBalance = chosenParty?.currentBalance ?: dashboardTotals.potliReceivable,
                    finalBalanceStatus = chosenParty?.balanceStatus ?: "बाकी आना",
                    tableHeaders = listOf("तारीख", "पार्टी", "कुल पोटली", "रेट", "कुल रकम", "प्राप्त भुगतान", "बाकी बैलेंस"),
                    tableRows = list.map {
                        listOf(it.date, it.partyName, it.totalPotli, it.rate, it.totalAmount, it.receivedPayment, it.remainingBalance)
                    },
                    paymentColumnIndex = 5
                )
            }

            ReportTypeOption.VEHICLE_RECORDS -> {
                val list = vehicleEntries.filter { v ->
                    v.dateEpoch in startEpoch..endEpoch &&
                        (monthYearFilter.isBlank() || v.monthYear == monthYearFilter)
                }
                val vSum = AccountingCalculator.calculateVehicleComparisonSummary(list)
                PdfReportDocumentData(
                    reportTitleHindi = "ओबाद से हैदराबाद गाड़ी रिपोर्ट",
                    subtitleHindi = "ओबाद बनाम हैदराबाद वजन तुलना रिपोर्ट",
                    partyOrSectionName = "कुल गाड़ियां: ${vSum.totalVehiclesCount}",
                    dateRangeLabel = rangeLabel,
                    previousBalance = vSum.totalObadWeight,
                    totalAmount = vSum.totalHyderabadWeight,
                    totalPaidOrReceived = vSum.totalOverallDiff,
                    finalBalance = vSum.totalOverallDiff,
                    finalBalanceStatus = "कुल वजन अंतर (कि.ग्रा.)",
                    monthlySummaryLines = listOf(
                        "बड़ा माल अंतर: ${vSum.totalBadaDiff}",
                        "वील माल अंतर: ${vSum.totalVeelDiff}"
                    ),
                    tableHeaders = listOf("तारीख", "गाड़ी नंबर", "ओबाद बड़ा/वील", "हैदराबाद बड़ा/वील", "ओबाद कुल", "हैदराबाद कुल", "वजन अंतर"),
                    tableRows = list.map {
                        listOf(
                            it.date,
                            it.vehicleNumber,
                            "${it.obadBadaWeight}/${it.obadVeelWeight}",
                            "${it.hyderabadBadaWeight}/${it.hyderabadVeelWeight}",
                            it.obadTotalWeight,
                            it.hyderabadTotalWeight,
                            it.totalWeightDiff
                        )
                    },
                    paymentColumnIndex = 6
                )
            }

            ReportTypeOption.MONTHLY_OVERALL, ReportTypeOption.YEARLY_OVERALL, ReportTypeOption.TOTAL_AANA_DENA -> {
                PdfReportDocumentData(
                    reportTitleHindi = selectedReportType.hindiTitle,
                    subtitleHindi = "सभी विभागों का कुल आना एवं कुल देना विवरण",
                    partyOrSectionName = "HAWELI मुख्य खाता सारांश",
                    dateRangeLabel = rangeLabel,
                    previousBalance = "0.00",
                    totalAmount = dashboardTotals.kulAana,
                    totalPaidOrReceived = dashboardTotals.kulDena,
                    finalBalance = dashboardTotals.kulAana,
                    finalBalanceStatus = "कुल आना: ₹${dashboardTotals.kulAana} | कुल देना: ₹${dashboardTotals.kulDena}",
                    tableHeaders = listOf("विभाग", "पार्टी का नाम", "शहर", "प्रारंभिक बैलेंस", "वर्तमान बाकी बैलेंस", "स्थिति"),
                    tableRows = parties.map {
                        listOf(
                            moduleHindiLabel(it.module),
                            it.name,
                            it.cityName.ifBlank { "-" },
                            it.openingBalance,
                            it.currentBalance,
                            it.balanceStatus
                        )
                    }
                )
            }
        }
    }

    Scaffold(
        topBar = {
            HaweliTopBar(
                title = "रिपोर्ट एवं हिंदी पीडीएफ सिस्टम",
                isConnected = isConnected,
                pendingWrites = pendingWrites,
                accessRole = accessRole,
                onBackClick = onBack,
                onSettingsClick = onOpenSettings
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = HaweliSurfaceLight),
                    border = BorderStroke(1.5.dp, HaweliDarkGreen),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "पीडीएफ रिपोर्ट विकल्प चुनें",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = HaweliNavyBlue
                        )

                        // Report Type Selector
                        ExposedDropdownMenuBox(
                            expanded = reportDropdownExpanded,
                            onExpandedChange = { reportDropdownExpanded = !reportDropdownExpanded }
                        ) {
                            OutlinedTextField(
                                value = selectedReportType.hindiTitle,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("रिपोर्ट का प्रकार") },
                                trailingIcon = {
                                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = reportDropdownExpanded)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = reportDropdownExpanded,
                                onDismissRequest = { reportDropdownExpanded = false }
                            ) {
                                ReportTypeOption.values().forEach { option ->
                                    DropdownMenuItem(
                                        text = { Text(option.hindiTitle) },
                                        onClick = {
                                            selectedReportType = option
                                            reportDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // Individual Party Selector
                        val selectedPartyObj = parties.find { it.id == selectedPartyId }
                        ExposedDropdownMenuBox(
                            expanded = partyDropdownExpanded,
                            onExpandedChange = { partyDropdownExpanded = !partyDropdownExpanded }
                        ) {
                            OutlinedTextField(
                                value = selectedPartyObj?.let { "${it.name} (${moduleHindiLabel(it.module)})" }
                                    ?: "सभी पार्टियां (कोई एक चुनें)",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("व्यक्तिगत पार्टी चुनें (वैकल्पिक)") },
                                trailingIcon = {
                                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = partyDropdownExpanded)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = partyDropdownExpanded,
                                onDismissRequest = { partyDropdownExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("सभी पार्टियां") },
                                    onClick = {
                                        selectedPartyId = ""
                                        partyDropdownExpanded = false
                                    }
                                )
                                parties.forEach { p ->
                                    DropdownMenuItem(
                                        text = { Text("${p.name} - ${moduleHindiLabel(p.module)}") },
                                        onClick = {
                                            selectedPartyId = p.id
                                            partyDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // City Selector (for City-wise report)
                        val selectedCityObj = cities.find { it.id == selectedCityId }
                        ExposedDropdownMenuBox(
                            expanded = cityDropdownExpanded,
                            onExpandedChange = { cityDropdownExpanded = !cityDropdownExpanded }
                        ) {
                            OutlinedTextField(
                                value = selectedCityObj?.name ?: "सभी शहर",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("शहर चुनें (शहर-वार रिपोर्ट हेतु)") },
                                trailingIcon = {
                                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = cityDropdownExpanded)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = cityDropdownExpanded,
                                onDismissRequest = { cityDropdownExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("सभी शहर") },
                                    onClick = {
                                        selectedCityId = ""
                                        cityDropdownExpanded = false
                                    }
                                )
                                cities.forEach { c ->
                                    DropdownMenuItem(
                                        text = { Text(c.name) },
                                        onClick = {
                                            selectedCityId = c.id
                                            cityDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // Date Range & Month/Year Inputs
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = startDateFilter,
                                onValueChange = { startDateFilter = it },
                                label = { Text("प्रारंभ तारीख (DD-MM-YYYY)", fontSize = 12.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = endDateFilter,
                                onValueChange = { endDateFilter = it },
                                label = { Text("अंतिम तारीख (DD-MM-YYYY)", fontSize = 12.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = monthYearFilter,
                                onValueChange = { monthYearFilter = it },
                                label = { Text("मासिक फ़िल्टर (MM-YYYY)", fontSize = 12.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = yearFilter,
                                onValueChange = { yearFilter = it },
                                label = { Text("वार्षिक फ़िल्टर (YYYY)", fontSize = 12.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Action Buttons: Save on Phone, Share on WhatsApp, Share via Other Apps, Print PDF
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val docData = buildReportData()
                                    val pdf = HaweliPdfGenerator.generatePdfFile(context, docData)
                                    lastGeneratedFile = pdf
                                    lastGeneratedTitle = docData.reportTitleHindi
                                    HaweliPdfGenerator.savePdfToDownloads(context, pdf)
                                    if (accessRole == AccessRole.ADMIN) {
                                        viewModel.repository.recordGeneratedReport(
                                            ReportMetadata(
                                                title = docData.reportTitleHindi,
                                                module = selectedReportType.name,
                                                dateRange = docData.dateRangeLabel,
                                                partyName = docData.partyOrSectionName,
                                                totalAmount = docData.totalAmount,
                                                totalPaidOrReceived = docData.totalPaidOrReceived,
                                                finalBalance = docData.finalBalance
                                            )
                                        )
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("फ़ोन में पीडीएफ सहेजें", color = Color.White)
                            }

                            Button(
                                onClick = {
                                    val docData = buildReportData()
                                    val pdf = HaweliPdfGenerator.generatePdfFile(context, docData)
                                    lastGeneratedFile = pdf
                                    lastGeneratedTitle = docData.reportTitleHindi
                                    HaweliPdfGenerator.sharePdfViaWhatsApp(context, pdf, docData.reportTitleHindi)
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B7A43))
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("व्हाट्सऐप पर भेजें", color = Color.White)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val docData = buildReportData()
                                    val pdf = HaweliPdfGenerator.generatePdfFile(context, docData)
                                    lastGeneratedFile = pdf
                                    lastGeneratedTitle = docData.reportTitleHindi
                                    HaweliPdfGenerator.sharePdfGeneric(context, pdf, docData.reportTitleHindi)
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Send, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("अन्य ऐप से भेजें")
                            }

                            OutlinedButton(
                                onClick = {
                                    val docData = buildReportData()
                                    val pdf = HaweliPdfGenerator.generatePdfFile(context, docData)
                                    lastGeneratedFile = pdf
                                    lastGeneratedTitle = docData.reportTitleHindi
                                    HaweliPdfGenerator.printPdfFile(context, pdf, docData.reportTitleHindi)
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Print, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("पीडीएफ प्रिंट करें")
                            }
                        }

                        lastGeneratedFile?.let { file ->
                            Text(
                                text = "तैयार पीडीएफ: ${file.name} ($lastGeneratedTitle)",
                                fontSize = 13.sp,
                                color = HaweliPositiveGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = "हाल ही में बनाई गई रिपोर्ट (${savedReports.size})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = HaweliNavyBlue
                )
            }

            items(savedReports.take(15), key = { it.id }) { rep ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, HaweliCardBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(rep.title, fontWeight = FontWeight.Bold, color = HaweliNavyBlue)
                        Text("पार्टी/विभाग: ${rep.partyName} | अवधि: ${rep.dateRange}", fontSize = 13.sp)
                        Text(
                            text = "कुल रकम: ${DateAndFormatUtils.formatIndianCurrency(rep.totalAmount)} | भुगतान: ${DateAndFormatUtils.formatIndianCurrency(rep.totalPaidOrReceived)}",
                            fontSize = 13.sp,
                            color = HaweliDarkGreen
                        )
                    }
                }
            }
        }
    }
}
