package com.haweli.viewer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haweli.models.AccessRole
import com.haweli.ui.theme.HaweliNavyBlue

/**
 * Compact banner displayed when the app is running in Viewer Mode (read-only access),
 * informing the viewer that live updates from the Admin sync automatically and providing
 * a quick button to open Admin Login if the user is the Admin.
 */
@Composable
fun ViewerModeBanner(
    accessRole: AccessRole,
    onAdminLoginClick: () -> Unit
) {
    if (accessRole == AccessRole.VIEWER) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFE8EEF7))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Default.Visibility,
                    contentDescription = "व्यूअर मोड",
                    tint = HaweliNavyBlue
                )
                Text(
                    text = "व्यूअर मोड: केवल देखने, खोजने और पीडीएफ रिपोर्ट के लिए (लाइव सिंक चालू)",
                    color = HaweliNavyBlue,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            TextButton(onClick = onAdminLoginClick) {
                Text(
                    text = "एडमिन लॉगिन",
                    color = HaweliNavyBlue,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}
