package com.haweli.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haweli.models.AccessRole
import com.haweli.models.BalanceStatus
import com.haweli.ui.theme.*
import com.haweli.utils.DateAndFormatUtils

/**
 * Top Bar used across all HAWELI modules displaying:
 * - Hindi Module Title
 * - Realtime Firebase Sync Badge (ऑनलाइन सिंक / ऑफ़लाइन कतार)
 * - Current Access Mode Badge (एडमिन / व्यूअर)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HaweliTopBar(
    title: String,
    isConnected: Boolean,
    pendingWrites: Int,
    accessRole: AccessRole,
    onBackClick: (() -> Unit)? = null,
    onSettingsClick: (() -> Unit)? = null
) {
    TopAppBar(
        title = {
            Column {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val syncText = when {
                        !isConnected && pendingWrites > 0 -> "ऑफ़लाइन ($pendingWrites बदलाव कतार में)"
                        !isConnected -> "ऑफ़लाइन कैश मोड"
                        pendingWrites > 0 -> "सिंक हो रहा है ($pendingWrites)..."
                        else -> "लाइव सिंक सक्रिय"
                    }
                    Text(
                        text = "● $syncText",
                        color = if (isConnected) Color(0xFFA5D6A7) else Color(0xFFFFCC80),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = if (accessRole == AccessRole.ADMIN) "| एडमिन मोड" else "| व्यूअर मोड",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 12.sp
                    )
                }
            }
        },
        navigationIcon = {
            if (onBackClick != null) {
                IconButton(onClick = onBackClick) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "वापस जाएं",
                        tint = Color.White
                    )
                }
            }
        },
        actions = {
            if (onSettingsClick != null) {
                IconButton(onClick = onSettingsClick) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "सेटिंग",
                        tint = Color.White
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = HaweliDarkGreen
        )
    )
}

/**
 * Search and Date/Month/Year/Sort Filter Bar required across every module.
 */
@Composable
fun ModuleSearchAndFilterBar(
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    searchPlaceholder: String = "पार्टी, शहर या गाड़ी नंबर खोजें...",
    dateFilter: String,
    onDateFilterChange: (String) -> Unit,
    monthFilter: String,
    onMonthFilterChange: (String) -> Unit,
    yearFilter: String,
    onYearFilterChange: (String) -> Unit,
    newestFirst: Boolean,
    onSortToggle: () -> Unit,
    onClearFilters: () -> Unit
) {
    var showAdvancedFilters by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = HaweliSurfaceLight),
        border = BorderStroke(1.dp, HaweliCardBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text(searchPlaceholder, fontSize = 14.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "खोजें") },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchChange("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "साफ़ करें")
                            }
                        }
                    },
                    singleLine = true
                )
                FilledTonalIconButton(onClick = { showAdvancedFilters = !showAdvancedFilters }) {
                    Icon(Icons.Default.FilterList, contentDescription = "फ़िल्टर")
                }
                FilledTonalIconButton(onClick = onSortToggle) {
                    Icon(Icons.Default.Sort, contentDescription = "क्रम बदलें")
                }
            }

            if (showAdvancedFilters) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = dateFilter,
                        onValueChange = onDateFilterChange,
                        modifier = Modifier.weight(1f),
                        label = { Text("तारीख (DD-MM-YYYY)", fontSize = 12.sp) },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = monthFilter,
                        onValueChange = onMonthFilterChange,
                        modifier = Modifier.weight(1f),
                        label = { Text("महीना (MM-YYYY)", fontSize = 12.sp) },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = yearFilter,
                        onValueChange = onYearFilterChange,
                        modifier = Modifier.weight(0.8f),
                        label = { Text("साल (YYYY)", fontSize = 12.sp) },
                        singleLine = true
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (newestFirst) "क्रम: सबसे नया पहले" else "क्रम: सबसे पुराना पहले",
                        fontSize = 13.sp,
                        color = HaweliNavyBlue,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = onSortToggle) {
                            Text(if (newestFirst) "पुराना पहले करें" else "नया पहले करें")
                        }
                        TextButton(onClick = onClearFilters) {
                            Text("सभी लेनदेन दिखाएं (फ़िल्टर हटाएं)", color = HaweliPaymentRed)
                        }
                    }
                }
            }
        }
    }
}

/**
 * Displays a colored Balance Badge following HAWELI rules:
 * - Positive balance -> Green colour (#1B7A43)
 * - Negative balance -> Red colour (#C62828)
 * - Payment amount -> Always Red colour (#C62828)
 */
@Composable
fun BalanceBadge(
    balanceAmount: String,
    balanceStatusLabel: String
) {
    val isNegative = balanceAmount.trim().startsWith("-")
    val isZero = balanceStatusLabel == BalanceStatus.HISAB_BARABAR.hindiLabel
    val bgColor = when {
        isZero -> Color(0xFFECEFF1)
        isNegative -> HaweliPaymentRedLight
        else -> HaweliPositiveGreenLight
    }
    val textColor = when {
        isZero -> HaweliNavyBlue
        isNegative -> HaweliPaymentRed
        else -> HaweliPositiveGreen
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, textColor.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "$balanceStatusLabel:",
                color = textColor,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Text(
                text = DateAndFormatUtils.formatIndianCurrency(balanceAmount),
                color = textColor,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp
            )
        }
    }
}

/**
 * Displays Payment / Received Payment strictly in RED colour with its payment date.
 */
@Composable
fun RedPaymentRow(
    label: String,
    paymentAmount: String,
    paymentDate: String
) {
    Surface(
        color = HaweliPaymentRedLight,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$label (तारीख: ${paymentDate.ifBlank { "-" }})",
                color = HaweliPaymentRed,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Text(
                text = DateAndFormatUtils.formatIndianCurrency(paymentAmount),
                color = HaweliPaymentRed,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp
            )
        }
    }
}

/**
 * Reusable Decimal / Numeric OutlinedTextField with Hindi label.
 */
@Composable
fun HindiDecimalField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = { input ->
            val filtered = input.filter { it.isDigit() || it == '.' || it == '-' }
            onValueChange(filtered)
        },
        label = { Text(label, fontSize = 13.sp) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        modifier = modifier
    )
}

/**
 * Confirmation dialog before deleting any record or restoring backup.
 */
@Composable
fun ConfirmDeleteDialog(
    title: String = "हटाने की पुष्टि करें",
    message: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold, color = HaweliPaymentRed) },
        text = { Text(message, fontSize = 15.sp) },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = HaweliPaymentRed)
            ) {
                Text("हाँ, हटाएं", color = Color.White)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("रद्द करें")
            }
        }
    )
}
