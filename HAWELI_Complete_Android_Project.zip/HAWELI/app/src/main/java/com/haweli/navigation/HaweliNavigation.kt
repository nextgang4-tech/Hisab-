package com.haweli.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.haweli.HaweliViewModel
import com.haweli.ui.screens.*

/**
 * All navigation destinations corresponding to the 8 main menu sections of HAWELI.
 */
object HaweliRoutes {
    const val HOME_DASHBOARD = "home_dashboard"
    const val FOUR_PC_PARTY = "four_pc_party"
    const val HYDERABAD_COMPANY = "hyderabad_company"
    const val CHAMDA = "chamda_module"
    const val KENA = "kena_module"
    const val POTLI = "potli_module"
    const val OBAD_HYDERABAD_GAADI = "obad_hyderabad_gaadi"
    const val REPORTS = "reports_module"
    const val SETTINGS = "settings_module"
}

@Composable
fun HaweliNavGraph(
    navController: NavHostController,
    viewModel: HaweliViewModel
) {
    NavHost(
        navController = navController,
        startDestination = HaweliRoutes.HOME_DASHBOARD
    ) {
        composable(HaweliRoutes.HOME_DASHBOARD) {
            HomeDashboardScreen(
                viewModel = viewModel,
                onNavigate = { route -> navController.navigate(route) }
            )
        }
        composable(HaweliRoutes.FOUR_PC_PARTY) {
            FourPcPartyScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onOpenSettings = { navController.navigate(HaweliRoutes.SETTINGS) }
            )
        }
        composable(HaweliRoutes.HYDERABAD_COMPANY) {
            HyderabadCompanyScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onOpenSettings = { navController.navigate(HaweliRoutes.SETTINGS) }
            )
        }
        composable(HaweliRoutes.CHAMDA) {
            ChamdaScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onOpenSettings = { navController.navigate(HaweliRoutes.SETTINGS) }
            )
        }
        composable(HaweliRoutes.KENA) {
            KenaScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onOpenSettings = { navController.navigate(HaweliRoutes.SETTINGS) }
            )
        }
        composable(HaweliRoutes.POTLI) {
            PotliScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onOpenSettings = { navController.navigate(HaweliRoutes.SETTINGS) }
            )
        }
        composable(HaweliRoutes.OBAD_HYDERABAD_GAADI) {
            ObadHyderabadGaadiScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onOpenSettings = { navController.navigate(HaweliRoutes.SETTINGS) }
            )
        }
        composable(HaweliRoutes.REPORTS) {
            ReportsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onOpenSettings = { navController.navigate(HaweliRoutes.SETTINGS) }
            )
        }
        composable(HaweliRoutes.SETTINGS) {
            SettingsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
