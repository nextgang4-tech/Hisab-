package com.haweli.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haweli.HaweliViewModel
import com.haweli.admin.AdminLoginDialog
import com.haweli.admin.AdminOnlySection
import com.haweli.backup.BackupManager
import com.haweli.database.DatabasePaths
import com.haweli.models.AccessRole
import com.haweli.models.HaweliBackupPayload
import com.haweli.pdf.HaweliPdfGenerator
import com.haweli.pdf.PdfReportDocumentData
import com.haweli.ui.components.HaweliTopBar
import com.haweli.ui.theme.*
import com.haweli.utils.AppShareUtils
import com.haweli.utils.DateAndFormatUtils

/**
 * 13. SETTINGS & 14. BACKUP AND RESTORE SCREEN (सेटिंग मेनू)
 * Implements all 10 required Settings options in Hindi:
 * 1. Admin Login (एडमिन लॉगिन)
 * 2. Admin Logout (एडमिन लॉगआउट)
 * 3. Change Password (पासवर्ड बदलें)
 * 4. Sync Status (सिंक स्थिति)
 * 5. Backup Data (डेटा बैकअप - JSON एक्सपोर्ट व शेयर)
 * 6. Restore Data (डेटा रीस्टोर - JSON सत्यापन व पुष्टि संवाद)
 * 7. Export PDF (संपूर्ण सारांश पीडीएफ एक्सपोर्ट)
 * 8. Share Application (एप्लीकेशन APK या डाउनलोड लिंक साझा करें)
 * 9. Application Information (एप्लीकेशन की जानकारी)
 * 10. Database Connection Status (डेटाबेस कनेक्शन स्थिति)
 */
@Composable
fun SettingsScreen(
    viewModel: HaweliViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val isConnected by viewModel.isConnected.collectAsState()
    val pendingWrites by viewModel.pendingWriteCount.collectAsState()
    val accessRole by viewModel.accessRole.collectAsState()
    val authStatusMessage by viewModel.authStatusMessage.collectAsState()
    val authError by viewModel.authError.collectAsState()
    val authBusy by viewModel.authBusy.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val parties by viewModel.parties.collectAsState()
    val dashboardTotals by viewModel.dashboardTotals.collectAsState()

    var showLoginDialog by remember { mutableStateOf(false) }
    var showChangePasswordDialog by remember { mutableStateOf(false) }
    var pendingRestorePayload by remember { mutableStateOf<HaweliBackupPayload?>(null) }
    var lastBackupTimeText by remember { mutableStateOf("अभी तक कोई स्थानीय बैकअप नहीं बनाया गया") }

    val restoreFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val validationResult = BackupManager.parseAndValidateBackupFromUri(context, uri)
            validationResult.onSuccess { payload ->
                pendingRestorePayload = payload
            }.onFailure { err ->
                Toast.makeText(
                    context,
                    err.message ?: "अमान्य बैकअप फ़ाइल",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    Scaffold(
        topBar = {
            HaweliTopBar(
                title = "सेटिंग एवं सुरक्षा प्रबंधन",
                isConnected = isConnected,
                pendingWrites = pendingWrites,
                accessRole = accessRole,
                onBackClick = onBack
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 28.dp)
        ) {
            // STATUS CARD (Options 4 & 10: Sync Status & Database Connection Status)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = HaweliSurfaceLight),
                    border = BorderStroke(1.5.dp, HaweliDarkGreen),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "4 & 10. सिंक एवं डेटाबेस कनेक्शन स्थिति",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = HaweliNavyBlue
                        )
                        Text(
                            text = "वर्तमान मोड: ${if (accessRole == AccessRole.ADMIN) "एडमिन मोड (पूर्ण अधिकार)" else "व्यूअर मोड (केवल देखने की अनुमति)"}",
                            fontWeight = FontWeight.Bold,
                            color = if (accessRole == AccessRole.ADMIN) HaweliPositiveGreen else HaweliNavyBlue
                        )
                        Text("प्रमाणीकरण स्थिति: $authStatusMessage", fontSize = 14.sp)
                        Text(
                            text = "डेटाबेस कनेक्शन: ${if (isConnected) "ऑनलाइन (रीयलटाइम सिंक चालू)" else "ऑफ़लाइन (स्थानीय कैश सक्रिय)"}",
                            fontWeight = FontWeight.SemiBold,
                            color = if (isConnected) HaweliPositiveGreen else HaweliPaymentRed
                        )
                        Text(
                            text = "लंबित सिंक बदलाव (Pending Queue): $pendingWrites",
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Firebase URL: ${DatabasePaths.DATABASE_URL}",
                            fontSize = 12.5.sp,
                            color = Color.DarkGray
                        )
                    }
                }
            }

            // 1, 2, 3: ADMIN AUTHENTICATION & PASSWORD MANAGEMENT
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, HaweliCardBorder),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "1-3. एडमिन लॉगिन और पासवर्ड सुरक्षा",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = HaweliNavyBlue
                        )

                        if (accessRole == AccessRole.VIEWER) {
                            Button(
                                onClick = {
                                    viewModel.clearAuthError()
                                    showLoginDialog = true
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                            ) {
                                Icon(Icons.Default.Login, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("1. एडमिन लॉगिन (Admin Login)", color = Color.White)
                            }
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        viewModel.clearAuthError()
                                        showChangePasswordDialog = true
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = HaweliNavyBlue)
                                ) {
                                    Icon(Icons.Default.Password, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("3. पासवर्ड बदलें", color = Color.White)
                                }

                                Button(
                                    onClick = {
                                        viewModel.logoutAdmin()
                                        Toast.makeText(
                                            context,
                                            "एडमिन लॉगआउट सफल। अब व्यूअर मोड सक्रिय है।",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = HaweliPaymentRed)
                                ) {
                                    Icon(Icons.Default.Logout, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("2. एडमिन लॉगआउट", color = Color.White)
                                }
                            }
                        }
                    }
                }
            }

            // 5 & 6: BACKUP AND RESTORE (JSON)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, HaweliCardBorder),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "5-6. संपूर्ण डेटा बैकअप और रीस्टोर (JSON)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = HaweliNavyBlue
                        )
                        Text(
                            text = "बैकअप तारीख व समय: $lastBackupTimeText",
                            fontSize = 13.5.sp,
                            color = Color.DarkGray
                        )

                        AdminOnlySection(accessRole) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = {
                                            val payload = viewModel.repository.buildBackupPayload()
                                            val file = BackupManager.createBackupJsonFile(context, payload)
                                            BackupManager.saveBackupToDownloads(context, file)
                                            lastBackupTimeText = payload.backupDateFormatted
                                        },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                                    ) {
                                        Icon(Icons.Default.Backup, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("5. JSON बैकअप सहेजें", color = Color.White)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            val payload = viewModel.repository.buildBackupPayload()
                                            val file = BackupManager.createBackupJsonFile(context, payload)
                                            lastBackupTimeText = payload.backupDateFormatted
                                            BackupManager.shareBackupFile(context, file)
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("बैकअप साझा करें")
                                    }
                                }

                                Button(
                                    onClick = { restoreFilePicker.launch("application/json") },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = HaweliNavyBlue)
                                ) {
                                    Icon(Icons.Default.Restore, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("6. JSON बैकअप फ़ाइल से डेटा रीस्टोर करें", color = Color.White)
                                }
                            }
                        }

                        if (accessRole == AccessRole.VIEWER) {
                            Text(
                                text = "नोट: डेटा बैकअप और रीस्टोर करने के लिए एडमिन लॉगिन आवश्यक है।",
                                fontSize = 13.sp,
                                color = HaweliPaymentRed
                            )
                        }
                    }
                }
            }

            // 7 & 8: EXPORT PDF & SHARE APPLICATION APK
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, HaweliCardBorder),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "7-8. पीडीएफ एक्सपोर्ट और एप्लीकेशन (APK) शेयर",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = HaweliNavyBlue
                        )

                        Button(
                            onClick = {
                                val docData = PdfReportDocumentData(
                                    reportTitleHindi = "HAWELI संपूर्ण खाता सारांश रिपोर्ट",
                                    subtitleHindi = "कुल आना एवं कुल देना विवरण",
                                    partyOrSectionName = "सभी पार्टियां (${parties.size})",
                                    dateRangeLabel = DateAndFormatUtils.todayFormatted(),
                                    previousBalance = "0.00",
                                    totalAmount = dashboardTotals.kulAana,
                                    totalPaidOrReceived = dashboardTotals.kulDena,
                                    finalBalance = dashboardTotals.kulAana,
                                    finalBalanceStatus = "कुल आना: ₹${dashboardTotals.kulAana} | कुल देना: ₹${dashboardTotals.kulDena}",
                                    tableHeaders = listOf("विभाग", "पार्टी का नाम", "शहर", "वर्तमान बैलेंस", "स्थिति"),
                                    tableRows = parties.map {
                                        listOf(
                                            moduleHindiLabel(it.module),
                                            it.name,
                                            it.cityName.ifBlank { "-" },
                                            it.currentBalance,
                                            it.balanceStatus
                                        )
                                    }
                                )
                                val pdf = HaweliPdfGenerator.generatePdfFile(context, docData)
                                HaweliPdfGenerator.savePdfToDownloads(context, pdf)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("7. संपूर्ण खाता पीडीएफ एक्सपोर्ट करें (Export PDF)", color = Color.White)
                        }

                        Button(
                            onClick = {
                                AppShareUtils.shareApplicationApkOrLink(
                                    context = context,
                                    fallbackDownloadUrl = settings.apkDownloadUrl
                                )
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = HaweliNavyBlue)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("8. HAWELI एप्लीकेशन (APK) दूसरे फ़ोन पर भेजें", color = Color.White)
                        }
                    }
                }
            }

            // 9. APPLICATION INFORMATION
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = HaweliSurfaceLight),
                    border = BorderStroke(1.dp, HaweliCardBorder),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Text(
                            text = "9. एप्लीकेशन की जानकारी (Application Information)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = HaweliNavyBlue
                        )
                        Text("एप्लीकेशन का नाम: HAWELI (हवेली बिज़नेस अकाउंटिंग)")
                        Text("संस्करण (Version): 1.0.0 (Production)")
                        Text("तकनीक: Kotlin, Jetpack Compose, Material 3, Firebase Realtime Database")
                        Text("गणना प्रणाली: BigDecimal (दशमलव-सुरक्षित सटीक वित्तीय गणना)")
                        Text("भाषा: सरल एवं व्यावसायिक हिंदी")
                    }
                }
            }
        }
    }

    if (showLoginDialog) {
        AdminLoginDialog(
            errorMessage = authError,
            isBusy = authBusy,
            onLoginSubmit = { user, pass ->
                viewModel.loginAdmin(user, pass) {
                    showLoginDialog = false
                }
            },
            onDismiss = { showLoginDialog = false }
        )
    }

    if (showChangePasswordDialog) {
        var currentPass by remember { mutableStateOf("") }
        var newPass by remember { mutableStateOf("") }
        var confirmPass by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showChangePasswordDialog = false },
            title = { Text("एडमिन पासवर्ड बदलें", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = currentPass,
                        onValueChange = { currentPass = it },
                        label = { Text("वर्तमान पासवर्ड") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newPass,
                        onValueChange = { newPass = it },
                        label = { Text("नया पासवर्ड (कम से कम 6 अक्षर)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = confirmPass,
                        onValueChange = { confirmPass = it },
                        label = { Text("नया पासवर्ड पुनः दर्ज करें") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (!authError.isNullOrBlank()) {
                        Text(authError!!, color = HaweliPaymentRed, fontSize = 13.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.changeAdminPassword(currentPass, newPass, confirmPass) {
                            showChangePasswordDialog = false
                            Toast.makeText(
                                context,
                                "पासवर्ड सफलतापूर्वक बदल दिया गया है।",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    },
                    enabled = !authBusy,
                    colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                ) {
                    Text(if (authBusy) "बदला जा रहा है..." else "पासवर्ड अपडेट करें", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showChangePasswordDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    // Confirmation dialog before restoring JSON backup
    pendingRestorePayload?.let { payload ->
        AlertDialog(
            onDismissRequest = { pendingRestorePayload = null },
            title = {
                Text(
                    text = "बैकअप रीस्टोर करने की पुष्टि करें",
                    fontWeight = FontWeight.Bold,
                    color = HaweliPaymentRed
                )
            },
            text = {
                Text(
                    text = "यह बैकअप (${payload.backupDateFormatted}) वैध पाया गया है। इसमें ${payload.parties.size} पार्टियां, ${payload.fourPcEntries.size} 4PC एंट्री, और ${payload.hyderabadEntries.size} हैदराबाद एंट्री शामिल हैं।\n\nक्या आप निश्चित रूप से इस बैकअप को रीस्टोर करना चाहते हैं?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.repository.restoreFromBackupPayload(payload)
                        pendingRestorePayload = null
                        Toast.makeText(
                            context,
                            "संपूर्ण डेटा बैकअप सफलतापूर्वक रीस्टोर और सिंक हो गया है।",
                            Toast.LENGTH_LONG
                        ).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                ) {
                    Text("हाँ, सुरक्षित रूप से रीस्टोर करें", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { pendingRestorePayload = null }) {
                    Text("रद्द करें")
                }
            }
        )
    }
}
