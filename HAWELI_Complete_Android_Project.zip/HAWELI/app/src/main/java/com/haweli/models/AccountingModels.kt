package com.haweli.models

/**
 * Domain data models for the HAWELI Business Accounting & Management Application.
 * All financial and weight values are stored as exact decimal strings to guarantee
 * zero floating-point rounding errors across Firebase serialization and BigDecimal math.
 */

enum class AccessRole {
    ADMIN,
    VIEWER
}

enum class BalanceStatus(val hindiLabel: String) {
    BAKI_DENA("बाकी देना"),
    BAKI_AANA("बाकी आना"),
    ADVANCE("एडवांस"),
    HISAB_BARABAR("हिसाब बराबर")
}

data class AppSettings(
    val weightUnit: String = "कि.ग्रा. (Kg)",
    val countUnit: String = "नग (Pcs)",
    val apkDownloadUrl: String = "https://github.com/haweli-accounting/HAWELI/actions",
    val adminProvisioned: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

data class UserProfile(
    val uid: String = "",
    val username: String = "Haweli",
    val role: String = AccessRole.VIEWER.name,
    val mustChangePassword: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

data class CityRecord(
    val id: String = "",
    val name: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class PartyRecord(
    val id: String = "",
    val module: String = "", // FOUR_PC, HYDERABAD, CHAMDA_SALES, KENA, POTLI
    val cityId: String = "",
    val cityName: String = "",
    val name: String = "",
    val phone: String = "",
    val openingBalance: String = "0.00",
    val currentBalance: String = "0.00",
    val balanceStatus: String = BalanceStatus.HISAB_BARABAR.hindiLabel,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * 4. 4PC पार्टी हिसाब एंट्री
 */
data class FourPcEntry(
    val id: String = "",
    val cityId: String = "",
    val cityName: String = "",
    val partyId: String = "",
    val partyName: String = "",
    val date: String = "", // DD-MM-YYYY
    val dateEpoch: Long = 0L,
    val monthYear: String = "", // MM-YYYY
    val totalBadaMaalCount: String = "0",
    val badaMaalWeight: String = "0.00",
    val badaMaalRate: String = "0.00",
    val badaMaalAmount: String = "0.00",
    val totalVeelMaalCount: String = "0",
    val veelMaalWeight: String = "0.00",
    val veelMaalRate: String = "0.00",
    val veelMaalAmount: String = "0.00",
    val totalCombinedAmount: String = "0.00",
    val previousBalance: String = "0.00",
    val paymentDate: String = "", // DD-MM-YYYY
    val paymentAmount: String = "0.00",
    val remainingBalance: String = "0.00",
    val balanceStatus: String = BalanceStatus.HISAB_BARABAR.hindiLabel,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * 5. हैदराबाद कंपनी हिसाब एंट्री
 */
data class HyderabadEntry(
    val id: String = "",
    val partyId: String = "",
    val partyName: String = "",
    val date: String = "", // DD-MM-YYYY
    val dateEpoch: Long = 0L,
    val monthYear: String = "", // MM-YYYY
    val totalBadaMaalCount: String = "0",
    val badaMaalWeight: String = "0.00",
    val badaMaalRate: String = "0.00",
    val badaMaalAmount: String = "0.00",
    val totalVeelMaalCount: String = "0",
    val veelMaalWeight: String = "0.00",
    val veelMaalRate: String = "0.00",
    val veelMaalAmount: String = "0.00",
    val totalCombinedAmount: String = "0.00",
    val previousBalance: String = "0.00",
    val receivedPayment: String = "0.00",
    val paymentDate: String = "", // DD-MM-YYYY
    val remainingBalance: String = "0.00",
    val balanceStatus: String = BalanceStatus.HISAB_BARABAR.hindiLabel,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * 6A. चमड़ा आवक (Daily Inward Stock & Weight)
 */
data class ChamdaAwakEntry(
    val id: String = "",
    val date: String = "", // DD-MM-YYYY
    val dateEpoch: Long = 0L,
    val monthYear: String = "", // MM-YYYY
    val year: String = "", // YYYY
    val badaChamdaCount: String = "0",
    val badaChamdaWeight: String = "0.00",
    val veelChamdaCount: String = "0",
    val veelChamdaWeight: String = "0.00",
    val totalChamdaCount: String = "0",
    val totalWeight: String = "0.00",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * 6B. चमड़ा बिक्री (Party-wise Leather Sales)
 */
data class ChamdaBikriEntry(
    val id: String = "",
    val date: String = "", // DD-MM-YYYY
    val dateEpoch: Long = 0L,
    val monthYear: String = "", // MM-YYYY
    val year: String = "", // YYYY
    val partyId: String = "",
    val partyName: String = "",
    val badaChamdaCount: String = "0",
    val badaChamdaRate: String = "0.00",
    val badaChamdaAmount: String = "0.00",
    val veelChamdaCount: String = "0",
    val veelChamdaRate: String = "0.00",
    val veelChamdaAmount: String = "0.00",
    val totalSaleAmount: String = "0.00",
    val previousBalance: String = "0.00",
    val receivedPayment: String = "0.00",
    val paymentDate: String = "", // DD-MM-YYYY
    val remainingBalance: String = "0.00",
    val balanceStatus: String = BalanceStatus.HISAB_BARABAR.hindiLabel,
    val adminNegativeStockApproved: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class ChamdaOpeningStock(
    val openingBadaChamda: String = "0",
    val openingVeelChamda: String = "0",
    val updatedAt: Long = System.currentTimeMillis()
)

data class ChamdaStockSummary(
    val monthBadaAwak: String = "0",
    val monthVeelAwak: String = "0",
    val monthTotalAwak: String = "0",
    val monthTotalWeight: String = "0.00",
    val monthBadaSold: String = "0",
    val monthVeelSold: String = "0",
    val closingBadaStock: String = "0",
    val closingVeelStock: String = "0"
)

/**
 * 7. केना (Kena Accounting Entry)
 */
data class KenaEntry(
    val id: String = "",
    val partyId: String = "",
    val partyName: String = "",
    val date: String = "", // DD-MM-YYYY
    val dateEpoch: Long = 0L,
    val monthYear: String = "", // MM-YYYY
    val totalKena: String = "0.00",
    val rate: String = "0.00",
    val totalAmount: String = "0.00",
    val previousBalance: String = "0.00",
    val receivedPayment: String = "0.00",
    val paymentDate: String = "", // DD-MM-YYYY
    val remainingBalance: String = "0.00",
    val balanceStatus: String = BalanceStatus.HISAB_BARABAR.hindiLabel,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * 8. पोटली (Potli Accounting Entry)
 */
data class PotliEntry(
    val id: String = "",
    val partyId: String = "",
    val partyName: String = "",
    val date: String = "", // DD-MM-YYYY
    val dateEpoch: Long = 0L,
    val monthYear: String = "", // MM-YYYY
    val totalPotli: String = "0.00",
    val rate: String = "0.00",
    val totalAmount: String = "0.00",
    val previousBalance: String = "0.00",
    val receivedPayment: String = "0.00",
    val paymentDate: String = "", // DD-MM-YYYY
    val remainingBalance: String = "0.00",
    val balanceStatus: String = BalanceStatus.HISAB_BARABAR.hindiLabel,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * 9. ओबाद से हैदराबाद गाड़ी (Vehicle Transport & Weight Comparison Record)
 */
data class VehicleEntry(
    val id: String = "",
    val date: String = "", // DD-MM-YYYY
    val dateEpoch: Long = 0L,
    val monthYear: String = "", // MM-YYYY
    val vehicleNumber: String = "",
    val obadBadaWeight: String = "0.00",
    val obadVeelWeight: String = "0.00",
    val obadTotalWeight: String = "0.00",
    val hyderabadBadaWeight: String = "0.00",
    val hyderabadVeelWeight: String = "0.00",
    val hyderabadTotalWeight: String = "0.00",
    val badaWeightDiff: String = "0.00",
    val veelWeightDiff: String = "0.00",
    val totalWeightDiff: String = "0.00",
    val obadDetails: String = "",
    val hyderabadDetails: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class VehicleComparisonSummary(
    val totalVehiclesCount: Int = 0,
    val totalObadBadaWeight: String = "0.00",
    val totalHyderabadBadaWeight: String = "0.00",
    val totalBadaDiff: String = "0.00",
    val totalObadVeelWeight: String = "0.00",
    val totalHyderabadVeelWeight: String = "0.00",
    val totalVeelDiff: String = "0.00",
    val totalObadWeight: String = "0.00",
    val totalHyderabadWeight: String = "0.00",
    val totalOverallDiff: String = "0.00"
)

/**
 * Unified Payment Log Entry stored under /haweli/payments
 */
data class PaymentRecord(
    val id: String = "",
    val sourceEntryId: String = "",
    val module: String = "",
    val partyId: String = "",
    val partyName: String = "",
    val paymentDate: String = "",
    val dateEpoch: Long = 0L,
    val amount: String = "0.00",
    val paymentType: String = "", // PAID (भुगतान) or RECEIVED (प्राप्त भुगतान)
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Report Metadata Log stored under /haweli/reports
 */
data class ReportMetadata(
    val id: String = "",
    val title: String = "",
    val module: String = "",
    val dateRange: String = "",
    val partyName: String = "",
    val totalAmount: String = "0.00",
    val totalPaidOrReceived: String = "0.00",
    val finalBalance: String = "0.00",
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Dashboard Summary Totals (कुल आना & कुल देना)
 */
data class DashboardTotals(
    val kulAana: String = "0.00",
    val kulDena: String = "0.00",
    val fourPcPayable: String = "0.00",
    val fourPcAdvanceReceivable: String = "0.00",
    val hyderabadReceivable: String = "0.00",
    val chamdaSalesReceivable: String = "0.00",
    val kenaReceivable: String = "0.00",
    val potliReceivable: String = "0.00"
)

/**
 * Complete Full-Database Snapshot used for JSON Backup & Restore
 */
data class HaweliBackupPayload(
    val backupVersion: Int = 1,
    val applicationName: String = "HAWELI",
    val backupTimestamp: Long = System.currentTimeMillis(),
    val backupDateFormatted: String = "",
    val settings: AppSettings = AppSettings(),
    val cities: Map<String, CityRecord> = emptyMap(),
    val parties: Map<String, PartyRecord> = emptyMap(),
    val fourPcEntries: Map<String, FourPcEntry> = emptyMap(),
    val hyderabadEntries: Map<String, HyderabadEntry> = emptyMap(),
    val chamdaOpeningStock: ChamdaOpeningStock = ChamdaOpeningStock(),
    val chamdaAwakEntries: Map<String, ChamdaAwakEntry> = emptyMap(),
    val chamdaBikriEntries: Map<String, ChamdaBikriEntry> = emptyMap(),
    val kenaEntries: Map<String, KenaEntry> = emptyMap(),
    val potliEntries: Map<String, PotliEntry> = emptyMap(),
    val vehicleEntries: Map<String, VehicleEntry> = emptyMap(),
    val payments: Map<String, PaymentRecord> = emptyMap(),
    val reports: Map<String, ReportMetadata> = emptyMap()
)
