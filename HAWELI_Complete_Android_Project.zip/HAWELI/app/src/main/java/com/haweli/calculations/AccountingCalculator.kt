package com.haweli.calculations

import com.haweli.models.*
import com.haweli.utils.DateAndFormatUtils
import java.math.BigDecimal
import java.math.RoundingMode

/**
 * Decimal-safe financial and stock calculation engine for HAWELI.
 * Uses BigDecimal with HALF_UP rounding to 2 decimal places for all currency and weight operations.
 */
object AccountingCalculator {

    private const val SCALE = 2
    private val ROUNDING = RoundingMode.HALF_UP

    fun parseDecimal(value: String?): BigDecimal {
        if (value.isNullOrBlank()) return BigDecimal.ZERO.setScale(SCALE, ROUNDING)
        return try {
            BigDecimal(value.trim().replace(",", "")).setScale(SCALE, ROUNDING)
        } catch (e: NumberFormatException) {
            BigDecimal.ZERO.setScale(SCALE, ROUNDING)
        }
    }

    fun formatDecimal(value: BigDecimal): String {
        return value.setScale(SCALE, ROUNDING).toPlainString()
    }

    fun multiply(weightOrCount: String, rate: String): BigDecimal {
        val qty = parseDecimal(weightOrCount)
        val r = parseDecimal(rate)
        return qty.multiply(r).setScale(SCALE, ROUNDING)
    }

    fun add(a: String, b: String): BigDecimal {
        return parseDecimal(a).add(parseDecimal(b)).setScale(SCALE, ROUNDING)
    }

    fun subtract(a: String, b: String): BigDecimal {
        return parseDecimal(a).subtract(parseDecimal(b)).setScale(SCALE, ROUNDING)
    }

    /**
     * Formula: Opening/Previous Balance + New Charges - Payment = Closing Balance
     */
    fun calculateClosingBalance(
        previousBalance: String,
        newCharges: String,
        payment: String
    ): BigDecimal {
        val prev = parseDecimal(previousBalance)
        val charges = parseDecimal(newCharges)
        val paid = parseDecimal(payment)
        return prev.add(charges).subtract(paid).setScale(SCALE, ROUNDING)
    }

    /**
     * Payable module (4PC Party):
     * Positive -> बाकी देना
     * Negative -> एडवांस
     * Zero -> हिसाब बराबर
     */
    fun resolvePayableStatus(balance: BigDecimal): BalanceStatus {
        val cmp = balance.compareTo(BigDecimal.ZERO)
        return when {
            cmp > 0 -> BalanceStatus.BAKI_DENA
            cmp < 0 -> BalanceStatus.ADVANCE
            else -> BalanceStatus.HISAB_BARABAR
        }
    }

    /**
     * Receivable modules (Hyderabad Company, Chamda Bikri, Kena, Potli):
     * Positive -> बाकी आना
     * Negative -> एडवांस
     * Zero -> हिसाब बराबर
     */
    fun resolveReceivableStatus(balance: BigDecimal): BalanceStatus {
        val cmp = balance.compareTo(BigDecimal.ZERO)
        return when {
            cmp > 0 -> BalanceStatus.BAKI_AANA
            cmp < 0 -> BalanceStatus.ADVANCE
            else -> BalanceStatus.HISAB_BARABAR
        }
    }

    /**
     * Recalculates the entire chronological chain of 4PC Party entries for a single party
     * so editing or deleting an older transaction automatically updates every subsequent
     * entry's previousBalance and remainingBalance without double-counting.
     */
    fun recalculateFourPcPartyChain(
        openingBalance: String,
        entries: List<FourPcEntry>
    ): Pair<List<FourPcEntry>, BigDecimal> {
        val sorted = entries.sortedWith(
            compareBy<FourPcEntry> { it.dateEpoch }.thenBy { it.createdAt }
        )
        var runningBalance = parseDecimal(openingBalance)
        val updatedList = sorted.map { entry ->
            val badaAmt = multiply(entry.badaMaalWeight, entry.badaMaalRate)
            val veelAmt = multiply(entry.veelMaalWeight, entry.veelMaalRate)
            val totalAmt = badaAmt.add(veelAmt).setScale(SCALE, ROUNDING)
            val prevBal = runningBalance
            val paidAmt = parseDecimal(entry.paymentAmount)
            val remBal = prevBal.add(totalAmt).subtract(paidAmt).setScale(SCALE, ROUNDING)
            val status = resolvePayableStatus(remBal)
            runningBalance = remBal

            entry.copy(
                badaMaalAmount = formatDecimal(badaAmt),
                veelMaalAmount = formatDecimal(veelAmt),
                totalCombinedAmount = formatDecimal(totalAmt),
                previousBalance = formatDecimal(prevBal),
                paymentAmount = formatDecimal(paidAmt),
                remainingBalance = formatDecimal(remBal),
                balanceStatus = status.hindiLabel
            )
        }
        return Pair(updatedList, runningBalance)
    }

    /**
     * Recalculates the chronological chain of Hyderabad Company entries for a party.
     */
    fun recalculateHyderabadPartyChain(
        openingBalance: String,
        entries: List<HyderabadEntry>
    ): Pair<List<HyderabadEntry>, BigDecimal> {
        val sorted = entries.sortedWith(
            compareBy<HyderabadEntry> { it.dateEpoch }.thenBy { it.createdAt }
        )
        var runningBalance = parseDecimal(openingBalance)
        val updatedList = sorted.map { entry ->
            val badaAmt = multiply(entry.badaMaalWeight, entry.badaMaalRate)
            val veelAmt = multiply(entry.veelMaalWeight, entry.veelMaalRate)
            val totalAmt = badaAmt.add(veelAmt).setScale(SCALE, ROUNDING)
            val prevBal = runningBalance
            val recAmt = parseDecimal(entry.receivedPayment)
            val remBal = prevBal.add(totalAmt).subtract(recAmt).setScale(SCALE, ROUNDING)
            val status = resolveReceivableStatus(remBal)
            runningBalance = remBal

            entry.copy(
                badaMaalAmount = formatDecimal(badaAmt),
                veelMaalAmount = formatDecimal(veelAmt),
                totalCombinedAmount = formatDecimal(totalAmt),
                previousBalance = formatDecimal(prevBal),
                receivedPayment = formatDecimal(recAmt),
                remainingBalance = formatDecimal(remBal),
                balanceStatus = status.hindiLabel
            )
        }
        return Pair(updatedList, runningBalance)
    }

    /**
     * Recalculates the chronological chain of Chamda Bikri (Sales) entries for a party.
     */
    fun recalculateChamdaBikriPartyChain(
        openingBalance: String,
        entries: List<ChamdaBikriEntry>
    ): Pair<List<ChamdaBikriEntry>, BigDecimal> {
        val sorted = entries.sortedWith(
            compareBy<ChamdaBikriEntry> { it.dateEpoch }.thenBy { it.createdAt }
        )
        var runningBalance = parseDecimal(openingBalance)
        val updatedList = sorted.map { entry ->
            val badaAmt = multiply(entry.badaChamdaCount, entry.badaChamdaRate)
            val veelAmt = multiply(entry.veelChamdaCount, entry.veelChamdaRate)
            val totalAmt = badaAmt.add(veelAmt).setScale(SCALE, ROUNDING)
            val prevBal = runningBalance
            val recAmt = parseDecimal(entry.receivedPayment)
            val remBal = prevBal.add(totalAmt).subtract(recAmt).setScale(SCALE, ROUNDING)
            val status = resolveReceivableStatus(remBal)
            runningBalance = remBal

            entry.copy(
                badaChamdaAmount = formatDecimal(badaAmt),
                veelChamdaAmount = formatDecimal(veelAmt),
                totalSaleAmount = formatDecimal(totalAmt),
                previousBalance = formatDecimal(prevBal),
                receivedPayment = formatDecimal(recAmt),
                remainingBalance = formatDecimal(remBal),
                balanceStatus = status.hindiLabel
            )
        }
        return Pair(updatedList, runningBalance)
    }

    /**
     * Recalculates the chronological chain of Kena entries for a party.
     */
    fun recalculateKenaPartyChain(
        openingBalance: String,
        entries: List<KenaEntry>
    ): Pair<List<KenaEntry>, BigDecimal> {
        val sorted = entries.sortedWith(
            compareBy<KenaEntry> { it.dateEpoch }.thenBy { it.createdAt }
        )
        var runningBalance = parseDecimal(openingBalance)
        val updatedList = sorted.map { entry ->
            val totalAmt = multiply(entry.totalKena, entry.rate)
            val prevBal = runningBalance
            val recAmt = parseDecimal(entry.receivedPayment)
            val remBal = prevBal.add(totalAmt).subtract(recAmt).setScale(SCALE, ROUNDING)
            val status = resolveReceivableStatus(remBal)
            runningBalance = remBal

            entry.copy(
                totalAmount = formatDecimal(totalAmt),
                previousBalance = formatDecimal(prevBal),
                receivedPayment = formatDecimal(recAmt),
                remainingBalance = formatDecimal(remBal),
                balanceStatus = status.hindiLabel
            )
        }
        return Pair(updatedList, runningBalance)
    }

    /**
     * Recalculates the chronological chain of Potli entries for a party.
     */
    fun recalculatePotliPartyChain(
        openingBalance: String,
        entries: List<PotliEntry>
    ): Pair<List<PotliEntry>, BigDecimal> {
        val sorted = entries.sortedWith(
            compareBy<PotliEntry> { it.dateEpoch }.thenBy { it.createdAt }
        )
        var runningBalance = parseDecimal(openingBalance)
        val updatedList = sorted.map { entry ->
            val totalAmt = multiply(entry.totalPotli, entry.rate)
            val prevBal = runningBalance
            val recAmt = parseDecimal(entry.receivedPayment)
            val remBal = prevBal.add(totalAmt).subtract(recAmt).setScale(SCALE, ROUNDING)
            val status = resolveReceivableStatus(remBal)
            runningBalance = remBal

            entry.copy(
                totalAmount = formatDecimal(totalAmt),
                previousBalance = formatDecimal(prevBal),
                receivedPayment = formatDecimal(recAmt),
                remainingBalance = formatDecimal(remBal),
                balanceStatus = status.hindiLabel
            )
        }
        return Pair(updatedList, runningBalance)
    }

    /**
     * Calculates Chamda Stock Summary:
     * Opening Stock + Total Received - Total Sold = Closing Stock
     */
    fun calculateChamdaStockSummary(
        openingStock: ChamdaOpeningStock,
        allAwak: List<ChamdaAwakEntry>,
        allBikri: List<ChamdaBikriEntry>,
        targetMonthYear: String
    ): ChamdaStockSummary {
        val openBada = parseDecimal(openingStock.openingBadaChamda)
        val openVeel = parseDecimal(openingStock.openingVeelChamda)

        var allTimeBadaAwak = BigDecimal.ZERO
        var allTimeVeelAwak = BigDecimal.ZERO
        var monthBadaAwak = BigDecimal.ZERO
        var monthVeelAwak = BigDecimal.ZERO
        var monthTotalWeight = BigDecimal.ZERO

        for (awak in allAwak) {
            val bada = parseDecimal(awak.badaChamdaCount)
            val veel = parseDecimal(awak.veelChamdaCount)
            val weight = parseDecimal(awak.totalWeight)
            allTimeBadaAwak = allTimeBadaAwak.add(bada)
            allTimeVeelAwak = allTimeVeelAwak.add(veel)
            if (awak.monthYear == targetMonthYear) {
                monthBadaAwak = monthBadaAwak.add(bada)
                monthVeelAwak = monthVeelAwak.add(veel)
                monthTotalWeight = monthTotalWeight.add(weight)
            }
        }

        var allTimeBadaSold = BigDecimal.ZERO
        var allTimeVeelSold = BigDecimal.ZERO
        var monthBadaSold = BigDecimal.ZERO
        var monthVeelSold = BigDecimal.ZERO

        for (bikri in allBikri) {
            val bada = parseDecimal(bikri.badaChamdaCount)
            val veel = parseDecimal(bikri.veelChamdaCount)
            allTimeBadaSold = allTimeBadaSold.add(bada)
            allTimeVeelSold = allTimeVeelSold.add(veel)
            if (bikri.monthYear == targetMonthYear) {
                monthBadaSold = monthBadaSold.add(bada)
                monthVeelSold = monthVeelSold.add(veel)
            }
        }

        val closingBada = openBada.add(allTimeBadaAwak).subtract(allTimeBadaSold)
        val closingVeel = openVeel.add(allTimeVeelAwak).subtract(allTimeVeelSold)
        val monthTotalAwak = monthBadaAwak.add(monthVeelAwak)

        return ChamdaStockSummary(
            monthBadaAwak = monthBadaAwak.setScale(0, ROUNDING).toPlainString(),
            monthVeelAwak = monthVeelAwak.setScale(0, ROUNDING).toPlainString(),
            monthTotalAwak = monthTotalAwak.setScale(0, ROUNDING).toPlainString(),
            monthTotalWeight = formatDecimal(monthTotalWeight),
            monthBadaSold = monthBadaSold.setScale(0, ROUNDING).toPlainString(),
            monthVeelSold = monthVeelSold.setScale(0, ROUNDING).toPlainString(),
            closingBadaStock = closingBada.setScale(0, ROUNDING).toPlainString(),
            closingVeelStock = closingVeel.setScale(0, ROUNDING).toPlainString()
        )
    }

    /**
     * Calculates Vehicle weight difference:
     * बड़ा माल अंतर = ओबाद बड़ा वजन - हैदराबाद बड़ा वजन
     * वील माल अंतर = ओबाद वील वजन - हैदराबाद वील वजन
     */
    fun enrichVehicleEntry(entry: VehicleEntry): VehicleEntry {
        val obadBada = parseDecimal(entry.obadBadaWeight)
        val obadVeel = parseDecimal(entry.obadVeelWeight)
        val obadTotal = obadBada.add(obadVeel).setScale(SCALE, ROUNDING)

        val hydBada = parseDecimal(entry.hyderabadBadaWeight)
        val hydVeel = parseDecimal(entry.hyderabadVeelWeight)
        val hydTotal = hydBada.add(hydVeel).setScale(SCALE, ROUNDING)

        val badaDiff = obadBada.subtract(hydBada).setScale(SCALE, ROUNDING)
        val veelDiff = obadVeel.subtract(hydVeel).setScale(SCALE, ROUNDING)
        val totalDiff = obadTotal.subtract(hydTotal).setScale(SCALE, ROUNDING)

        val epoch = DateAndFormatUtils.parseDateToEpoch(entry.date)
        val monthYear = DateAndFormatUtils.extractMonthYear(entry.date)

        return entry.copy(
            dateEpoch = epoch,
            monthYear = monthYear,
            obadBadaWeight = formatDecimal(obadBada),
            obadVeelWeight = formatDecimal(obadVeel),
            obadTotalWeight = formatDecimal(obadTotal),
            hyderabadBadaWeight = formatDecimal(hydBada),
            hyderabadVeelWeight = formatDecimal(hydVeel),
            hyderabadTotalWeight = formatDecimal(hydTotal),
            badaWeightDiff = formatDecimal(badaDiff),
            veelWeightDiff = formatDecimal(veelDiff),
            totalWeightDiff = formatDecimal(totalDiff)
        )
    }

    fun calculateVehicleComparisonSummary(entries: List<VehicleEntry>): VehicleComparisonSummary {
        var obadBada = BigDecimal.ZERO
        var hydBada = BigDecimal.ZERO
        var obadVeel = BigDecimal.ZERO
        var hydVeel = BigDecimal.ZERO

        for (v in entries) {
            obadBada = obadBada.add(parseDecimal(v.obadBadaWeight))
            hydBada = hydBada.add(parseDecimal(v.hyderabadBadaWeight))
            obadVeel = obadVeel.add(parseDecimal(v.obadVeelWeight))
            hydVeel = hydVeel.add(parseDecimal(v.hyderabadVeelWeight))
        }

        val badaDiff = obadBada.subtract(hydBada)
        val veelDiff = obadVeel.subtract(hydVeel)
        val obadTotal = obadBada.add(obadVeel)
        val hydTotal = hydBada.add(hydVeel)
        val overallDiff = obadTotal.subtract(hydTotal)

        return VehicleComparisonSummary(
            totalVehiclesCount = entries.size,
            totalObadBadaWeight = formatDecimal(obadBada),
            totalHyderabadBadaWeight = formatDecimal(hydBada),
            totalBadaDiff = formatDecimal(badaDiff),
            totalObadVeelWeight = formatDecimal(obadVeel),
            totalHyderabadVeelWeight = formatDecimal(hydVeel),
            totalVeelDiff = formatDecimal(veelDiff),
            totalObadWeight = formatDecimal(obadTotal),
            totalHyderabadWeight = formatDecimal(hydTotal),
            totalOverallDiff = formatDecimal(overallDiff)
        )
    }

    /**
     * Computes Dashboard Totals (कुल आना & कुल देना) across all distinct parties without double-counting.
     * - Each party's latest closing balance is evaluated once per party ID.
     * - Payable module (FOUR_PC):
     *     Positive closing balance -> added to कुल देना
     *     Negative closing balance (Advance paid to supplier) -> absolute value added to कुल आना
     * - Receivable modules (HYDERABAD, CHAMDA_SALES, KENA, POTLI):
     *     Positive closing balance -> added to कुल आना
     *     Negative closing balance (Advance received from buyer) -> absolute value added to कुल देना
     */
    fun calculateDashboardTotals(parties: Collection<PartyRecord>): DashboardTotals {
        var kulAana = BigDecimal.ZERO
        var kulDena = BigDecimal.ZERO
        var fourPcPayable = BigDecimal.ZERO
        var fourPcAdvance = BigDecimal.ZERO
        var hydReceivable = BigDecimal.ZERO
        var chamdaReceivable = BigDecimal.ZERO
        var kenaReceivable = BigDecimal.ZERO
        var potliReceivable = BigDecimal.ZERO

        val uniqueParties = parties.distinctBy { "${it.module}:${it.id}" }

        for (party in uniqueParties) {
            val bal = parseDecimal(party.currentBalance)
            if (bal.compareTo(BigDecimal.ZERO) == 0) continue

            when (party.module) {
                "FOUR_PC" -> {
                    if (bal > BigDecimal.ZERO) {
                        kulDena = kulDena.add(bal)
                        fourPcPayable = fourPcPayable.add(bal)
                    } else {
                        val adv = bal.abs()
                        kulAana = kulAana.add(adv)
                        fourPcAdvance = fourPcAdvance.add(adv)
                    }
                }
                "HYDERABAD" -> {
                    if (bal > BigDecimal.ZERO) {
                        kulAana = kulAana.add(bal)
                        hydReceivable = hydReceivable.add(bal)
                    } else {
                        kulDena = kulDena.add(bal.abs())
                    }
                }
                "CHAMDA_SALES" -> {
                    if (bal > BigDecimal.ZERO) {
                        kulAana = kulAana.add(bal)
                        chamdaReceivable = chamdaReceivable.add(bal)
                    } else {
                        kulDena = kulDena.add(bal.abs())
                    }
                }
                "KENA" -> {
                    if (bal > BigDecimal.ZERO) {
                        kulAana = kulAana.add(bal)
                        kenaReceivable = kenaReceivable.add(bal)
                    } else {
                        kulDena = kulDena.add(bal.abs())
                    }
                }
                "POTLI" -> {
                    if (bal > BigDecimal.ZERO) {
                        kulAana = kulAana.add(bal)
                        potliReceivable = potliReceivable.add(bal)
                    } else {
                        kulDena = kulDena.add(bal.abs())
                    }
                }
            }
        }

        return DashboardTotals(
            kulAana = formatDecimal(kulAana),
            kulDena = formatDecimal(kulDena),
            fourPcPayable = formatDecimal(fourPcPayable),
            fourPcAdvanceReceivable = formatDecimal(fourPcAdvance),
            hyderabadReceivable = formatDecimal(hydReceivable),
            chamdaSalesReceivable = formatDecimal(chamdaReceivable),
            kenaReceivable = formatDecimal(kenaReceivable),
            potliReceivable = formatDecimal(potliReceivable)
        )
    }
}
