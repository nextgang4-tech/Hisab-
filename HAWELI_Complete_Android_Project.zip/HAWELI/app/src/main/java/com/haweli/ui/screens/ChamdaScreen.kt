package com.haweli.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haweli.HaweliViewModel
import com.haweli.admin.AdminOnlySection
import com.haweli.calculations.AccountingCalculator
import com.haweli.models.*
import com.haweli.ui.components.*
import com.haweli.ui.theme.*
import com.haweli.utils.DateAndFormatUtils

/**
 * 6. CHAMDA / चमड़ा MANAGEMENT SCREEN
 * Includes:
 * - Top Chamda Stock Dashboard:
 *   • इस महीने आया बड़ा चमड़ा
 *   • इस महीने आया वील चमड़ा
 *   • इस महीने बिका बड़ा चमड़ा
 *   • इस महीने बिका वील चमड़ा
 *   • कुल बचा हुआ बड़ा चमड़ा
 *   • कुल बचा हुआ वील चमड़ा
 * - Section A: चमड़ा आवक (Daily entries, monthly/yearly totals, date search)
 * - Section B: चमड़ा बिक्री (Party-wise sales, 13 fields, negative stock warning guard)
 */
@Composable
fun ChamdaScreen(
    viewModel: HaweliViewModel,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val isConnected by viewModel.isConnected.collectAsState()
    val pendingWrites by viewModel.pendingWriteCount.collectAsState()
    val accessRole by viewModel.accessRole.collectAsState()
    val openingStock by viewModel.chamdaOpeningStock.collectAsState()
    val awakEntries by viewModel.chamdaAwakEntries.collectAsState()
    val bikriEntries by viewModel.chamdaBikriEntries.collectAsState()
    val allParties by viewModel.parties.collectAsState()

    val chamdaParties = remember(allParties) {
        allParties.filter { it.module == "CHAMDA_SALES" }
    }

    var selectedTab by remember { mutableStateOf(0) } // 0 = चमड़ा आवक, 1 = चमड़ा बिक्री
    var selectedParty by remember { mutableStateOf<PartyRecord?>(null) }
    val activeParty = remember(selectedParty, chamdaParties) {
        selectedParty?.let { sel -> chamdaParties.find { it.id == sel.id } ?: sel }
    }

    var searchQuery by remember { mutableStateOf("") }
    var dateFilter by remember { mutableStateOf("") }
    var monthFilter by remember { mutableStateOf(DateAndFormatUtils.currentMonthYear()) }
    var yearFilter by remember { mutableStateOf("") }
    var newestFirst by remember { mutableStateOf(true) }

    val activeMonth = if (monthFilter.isNotBlank()) monthFilter.trim() else DateAndFormatUtils.currentMonthYear()
    val stockSummary = remember(openingStock, awakEntries, bikriEntries, activeMonth) {
        AccountingCalculator.calculateChamdaStockSummary(
            openingStock = openingStock,
            allAwak = awakEntries,
            allBikri = bikriEntries,
            targetMonthYear = activeMonth
        )
    }

    // Dialog states
    var showOpeningStockDialog by remember { mutableStateOf(false) }
    var showAwakDialog by remember { mutableStateOf(false) }
    var editingAwak by remember { mutableStateOf<ChamdaAwakEntry?>(null) }
    var awakToDelete by remember { mutableStateOf<ChamdaAwakEntry?>(null) }

    var showPartyDialog by remember { mutableStateOf(false) }
    var editingParty by remember { mutableStateOf<PartyRecord?>(null) }
    var partyToDelete by remember { mutableStateOf<PartyRecord?>(null) }

    var showBikriDialog by remember { mutableStateOf(false) }
    var editingBikri by remember { mutableStateOf<ChamdaBikriEntry?>(null) }
    var bikriToDelete by remember { mutableStateOf<ChamdaBikriEntry?>(null) }
    var pendingNegativeStockDraft by remember { mutableStateOf<ChamdaBikriEntry?>(null) }
    var negativeStockWarningText by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            HaweliTopBar(
                title = if (activeParty != null) "चमड़ा बिक्री: ${activeParty.name}" else "चमड़ा प्रबंधन (आवक, बिक्री व स्टॉक)",
                isConnected = isConnected,
                pendingWrites = pendingWrites,
                accessRole = accessRole,
                onBackClick = {
                    if (activeParty != null) selectedParty = null else onBack()
                },
                onSettingsClick = onOpenSettings
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(bottom = 28.dp)
        ) {
            // TOP CHAMDA STOCK DASHBOARD
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    colors = CardDefaults.cardColors(containerColor = HaweliSurfaceLight),
                    border = BorderStroke(1.5.dp, HaweliDarkGreen),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "चमड़ा स्टॉक डैशबोर्ड ($activeMonth)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                color = HaweliNavyBlue
                            )
                            AdminOnlySection(accessRole) {
                                TextButton(onClick = { showOpeningStockDialog = true }) {
                                    Text("ओपनिंग स्टॉक सेट करें", fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("इस महीने आया बड़ा चमड़ा: ${stockSummary.monthBadaAwak}", fontSize = 14.sp)
                            Text("इस महीने आया वील चमड़ा: ${stockSummary.monthVeelAwak}", fontSize = 14.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("इस महीने बिका बड़ा चमड़ा: ${stockSummary.monthBadaSold}", fontSize = 14.sp)
                            Text("इस महीने बिका वील चमड़ा: ${stockSummary.monthVeelSold}", fontSize = 14.sp)
                        }
                        Divider(color = HaweliCardBorder)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                text = "कुल बचा हुआ बड़ा चमड़ा: ${stockSummary.closingBadaStock}",
                                fontWeight = FontWeight.Bold,
                                color = if (stockSummary.closingBadaStock.startsWith("-")) HaweliPaymentRed else HaweliPositiveGreen,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "कुल बचा हुआ वील चमड़ा: ${stockSummary.closingVeelStock}",
                                fontWeight = FontWeight.Bold,
                                color = if (stockSummary.closingVeelStock.startsWith("-")) HaweliPaymentRed else HaweliPositiveGreen,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }

            // TAB SWITCHER: A. चमड़ा आवक | B. चमड़ा बिक्री
            item {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.White,
                    contentColor = HaweliDarkGreen
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = {
                            selectedTab = 0
                            selectedParty = null
                        },
                        text = { Text("A. चमड़ा आवक", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("B. चमड़ा बिक्री", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                    )
                }
            }

            // SEARCH AND FILTER BAR
            item {
                ModuleSearchAndFilterBar(
                    searchQuery = searchQuery,
                    onSearchChange = { searchQuery = it },
                    searchPlaceholder = "तारीख या पार्टी का नाम खोजें...",
                    dateFilter = dateFilter,
                    onDateFilterChange = { dateFilter = it },
                    monthFilter = monthFilter,
                    onMonthFilterChange = { monthFilter = it },
                    yearFilter = yearFilter,
                    onYearFilterChange = { yearFilter = it },
                    newestFirst = newestFirst,
                    onSortToggle = { newestFirst = !newestFirst },
                    onClearFilters = {
                        searchQuery = ""
                        dateFilter = ""
                        monthFilter = ""
                        yearFilter = ""
                    }
                )
            }

            // =================================================================
            // SECTION A: चमड़ा आवक
            // =================================================================
            if (selectedTab == 0) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = HaweliPositiveGreenLight),
                        border = BorderStroke(1.dp, HaweliPositiveGreen)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "इस महीने का चमड़ा आवक ($activeMonth)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = HaweliDarkGreen
                                )
                                AdminOnlySection(accessRole) {
                                    Button(
                                        onClick = {
                                            editingAwak = null
                                            showAwakDialog = true
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("दैनिक आवक जोड़ें")
                                    }
                                }
                            }
                            Text(
                                text = "• कुल बड़ा चमड़ा: ${stockSummary.monthBadaAwak}   |   • कुल वील चमड़ा: ${stockSummary.monthVeelAwak}",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "• कुल चमड़ा: ${stockSummary.monthTotalAwak} नग   |   • कुल वजन: ${stockSummary.monthTotalWeight} कि.ग्रा.",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = HaweliNavyBlue
                            )
                        }
                    }
                }

                val filteredAwakRaw = awakEntries.filter { e ->
                    (searchQuery.isBlank() || e.date.contains(searchQuery.trim())) &&
                        (dateFilter.isBlank() || e.date == dateFilter.trim()) &&
                        (monthFilter.isBlank() || e.monthYear == monthFilter.trim()) &&
                        (yearFilter.isBlank() || e.year == yearFilter.trim())
                }
                val filteredAwak = if (newestFirst) {
                    filteredAwakRaw.sortedByDescending { it.dateEpoch }
                } else {
                    filteredAwakRaw.sortedBy { it.dateEpoch }
                }

                items(filteredAwak, key = { "awak_${it.id}" }) { entry ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 5.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, HaweliCardBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "तारीख: ${entry.date}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = HaweliNavyBlue
                                )
                                AdminOnlySection(accessRole) {
                                    Row {
                                        IconButton(onClick = {
                                            editingAwak = entry
                                            showAwakDialog = true
                                        }) {
                                            Icon(Icons.Default.Edit, contentDescription = "बदलें", tint = HaweliNavyBlue)
                                        }
                                        IconButton(onClick = { awakToDelete = entry }) {
                                            Icon(Icons.Default.Delete, contentDescription = "हटाएं", tint = HaweliPaymentRed)
                                        }
                                    }
                                }
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("बड़ा चमड़ा: ${entry.badaChamdaCount} नग", fontSize = 14.sp)
                                Text("बड़ा चमड़ा का वजन: ${entry.badaChamdaWeight}", fontSize = 14.sp)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("वील चमड़ा: ${entry.veelChamdaCount} नग", fontSize = 14.sp)
                                Text("वील चमड़ा का वजन: ${entry.veelChamdaWeight}", fontSize = 14.sp)
                            }
                            Divider(color = HaweliCardBorder)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(
                                    text = "कुल चमड़ा: ${entry.totalChamdaCount} नग",
                                    fontWeight = FontWeight.Bold,
                                    color = HaweliDarkGreen
                                )
                                Text(
                                    text = "कुल वजन: ${entry.totalWeight} कि.ग्रा.",
                                    fontWeight = FontWeight.Bold,
                                    color = HaweliNavyBlue
                                )
                            }
                        }
                    }
                }
            }

            // =================================================================
            // SECTION B: चमड़ा बिक्री (Party List -> Sales Ledger)
            // =================================================================
            if (selectedTab == 1) {
                if (activeParty == null) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "चमड़ा बिक्री पार्टियां (${chamdaParties.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                color = HaweliNavyBlue
                            )
                            AdminOnlySection(accessRole) {
                                Button(
                                    onClick = {
                                        editingParty = null
                                        showPartyDialog = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                                ) {
                                    Icon(Icons.Default.PersonAdd, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("ग्राहक पार्टी जोड़ें")
                                }
                            }
                        }
                    }

                    val filteredParties = chamdaParties.filter {
                        searchQuery.isBlank() || it.name.contains(searchQuery.trim(), ignoreCase = true)
                    }

                    items(filteredParties, key = { "cparty_${it.id}" }) { party ->
                        Box(modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                            PartySummaryCard(
                                party = party,
                                accessRole = accessRole,
                                onClick = { selectedParty = party },
                                onEdit = {
                                    editingParty = party
                                    showPartyDialog = true
                                },
                                onDelete = { partyToDelete = party }
                            )
                        }
                    }
                } else {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            colors = CardDefaults.cardColors(containerColor = HaweliSurfaceLight),
                            border = BorderStroke(1.5.dp, HaweliDarkGreen)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "चमड़ा बिक्री पार्टी: ${activeParty.name}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 17.sp,
                                        color = HaweliNavyBlue
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    BalanceBadge(
                                        balanceAmount = activeParty.currentBalance,
                                        balanceStatusLabel = activeParty.balanceStatus
                                    )
                                }
                                AdminOnlySection(accessRole) {
                                    Button(
                                        onClick = {
                                            editingBikri = null
                                            showBikriDialog = true
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("नई बिक्री")
                                    }
                                }
                            }
                        }
                    }

                    val partySalesRaw = bikriEntries.filter { e ->
                        e.partyId == activeParty.id &&
                            (searchQuery.isBlank() || e.date.contains(searchQuery.trim())) &&
                            (dateFilter.isBlank() || e.date == dateFilter.trim()) &&
                            (monthFilter.isBlank() || e.monthYear == monthFilter.trim()) &&
                            (yearFilter.isBlank() || e.year == yearFilter.trim())
                    }
                    val partySales = if (newestFirst) {
                        partySalesRaw.sortedByDescending { it.dateEpoch }
                    } else {
                        partySalesRaw.sortedBy { it.dateEpoch }
                    }

                    items(partySales, key = { "bikri_${it.id}" }) { sale ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 5.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, HaweliCardBorder)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "1. तारीख: ${sale.date} | 2. पार्टी: ${sale.partyName}",
                                        fontWeight = FontWeight.Bold,
                                        color = HaweliNavyBlue
                                    )
                                    AdminOnlySection(accessRole) {
                                        Row {
                                            IconButton(onClick = {
                                                editingBikri = sale
                                                showBikriDialog = true
                                            }) {
                                                Icon(Icons.Default.Edit, contentDescription = "बदलें", tint = HaweliNavyBlue)
                                            }
                                            IconButton(onClick = { bikriToDelete = sale }) {
                                                Icon(Icons.Default.Delete, contentDescription = "हटाएं", tint = HaweliPaymentRed)
                                            }
                                        }
                                    }
                                }
                                Text(
                                    text = "3. बड़ा चमड़ा संख्या: ${sale.badaChamdaCount} × 4. रेट ₹${sale.badaChamdaRate} = 5. रकम ${DateAndFormatUtils.formatIndianCurrency(sale.badaChamdaAmount)}",
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "6. वील चमड़ा संख्या: ${sale.veelChamdaCount} × 7. रेट ₹${sale.veelChamdaRate} = 8. रकम ${DateAndFormatUtils.formatIndianCurrency(sale.veelChamdaAmount)}",
                                    fontSize = 14.sp
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "9. कुल बिक्री रकम: ${DateAndFormatUtils.formatIndianCurrency(sale.totalSaleAmount)}",
                                        fontWeight = FontWeight.Bold,
                                        color = HaweliDarkGreen
                                    )
                                    Text(
                                        text = "10. पिछला बैलेंस: ${DateAndFormatUtils.formatIndianCurrency(sale.previousBalance)}",
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                RedPaymentRow(
                                    label = "11-12. प्राप्त भुगतान",
                                    paymentAmount = sale.receivedPayment,
                                    paymentDate = sale.paymentDate
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("13. बाकी बैलेंस:", fontWeight = FontWeight.Bold)
                                    BalanceBadge(
                                        balanceAmount = sale.remainingBalance,
                                        balanceStatusLabel = sale.balanceStatus
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // DIALOGS
    if (showOpeningStockDialog) {
        var openBada by remember { mutableStateOf(openingStock.openingBadaChamda) }
        var openVeel by remember { mutableStateOf(openingStock.openingVeelChamda) }
        AlertDialog(
            onDismissRequest = { showOpeningStockDialog = false },
            title = { Text("प्रारंभिक (ओपनिंग) चमड़ा स्टॉक सेट करें") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    HindiDecimalField(
                        value = openBada,
                        onValueChange = { openBada = it },
                        label = "ओपनिंग बड़ा चमड़ा (नग)",
                        modifier = Modifier.fillMaxWidth()
                    )
                    HindiDecimalField(
                        value = openVeel,
                        onValueChange = { openVeel = it },
                        label = "ओपनिंग वील चमड़ा (नग)",
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.repository.saveChamdaOpeningStock(openBada, openVeel)
                        showOpeningStockDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                ) {
                    Text("सहेजें", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showOpeningStockDialog = false }) { Text("रद्द करें") }
            }
        )
    }

    if (showAwakDialog) {
        var date by remember { mutableStateOf(editingAwak?.date ?: DateAndFormatUtils.todayFormatted()) }
        var badaCount by remember { mutableStateOf(editingAwak?.badaChamdaCount ?: "0") }
        var badaWeight by remember { mutableStateOf(editingAwak?.badaChamdaWeight ?: "0.00") }
        var veelCount by remember { mutableStateOf(editingAwak?.veelChamdaCount ?: "0") }
        var veelWeight by remember { mutableStateOf(editingAwak?.veelChamdaWeight ?: "0.00") }

        val totalCount = AccountingCalculator.add(badaCount, veelCount).setScale(0).toPlainString()
        val totalWeight = AccountingCalculator.add(badaWeight, veelWeight).toPlainString()

        AlertDialog(
            onDismissRequest = { showAwakDialog = false },
            title = { Text(if (editingAwak == null) "चमड़ा आवक दैनिक एंट्री" else "चमड़ा आवक बदलें") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        label = { Text("तारीख (DD-MM-YYYY)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    HindiDecimalField(
                        value = badaCount,
                        onValueChange = { badaCount = it },
                        label = "बड़ा चमड़ा (नग)",
                        modifier = Modifier.fillMaxWidth()
                    )
                    HindiDecimalField(
                        value = badaWeight,
                        onValueChange = { badaWeight = it },
                        label = "बड़ा चमड़ा का वजन (कि.ग्रा.)",
                        modifier = Modifier.fillMaxWidth()
                    )
                    HindiDecimalField(
                        value = veelCount,
                        onValueChange = { veelCount = it },
                        label = "वील चमड़ा (नग)",
                        modifier = Modifier.fillMaxWidth()
                    )
                    HindiDecimalField(
                        value = veelWeight,
                        onValueChange = { veelWeight = it },
                        label = "वील चमड़ा का वजन (कि.ग्रा.)",
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("कुल चमड़ा: $totalCount नग | कुल वजन: $totalWeight कि.ग्रा.", fontWeight = FontWeight.Bold)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.repository.saveChamdaAwakEntry(
                            ChamdaAwakEntry(
                                id = editingAwak?.id ?: "",
                                date = date,
                                badaChamdaCount = badaCount,
                                badaChamdaWeight = badaWeight,
                                veelChamdaCount = veelCount,
                                veelChamdaWeight = veelWeight,
                                createdAt = editingAwak?.createdAt ?: System.currentTimeMillis()
                            )
                        )
                        showAwakDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                ) {
                    Text("सहेजें", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAwakDialog = false }) { Text("रद्द करें") }
            }
        )
    }

    awakToDelete?.let { entry ->
        ConfirmDeleteDialog(
            message = "क्या आप तारीख ${entry.date} की चमड़ा आवक एंट्री हटाना चाहते हैं?",
            onConfirm = { viewModel.repository.deleteChamdaAwakEntry(entry.id) },
            onDismiss = { awakToDelete = null }
        )
    }

    if (showPartyDialog) {
        var partyName by remember(editingParty) { mutableStateOf(editingParty?.name ?: "") }
        var openingBal by remember(editingParty) { mutableStateOf(editingParty?.openingBalance ?: "0.00") }
        AlertDialog(
            onDismissRequest = { showPartyDialog = false },
            title = { Text(if (editingParty == null) "चमड़ा बिक्री पार्टी जोड़ें" else "पार्टी का नाम बदलें") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = partyName,
                        onValueChange = { partyName = it },
                        label = { Text("पार्टी का नाम") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    HindiDecimalField(
                        value = openingBal,
                        onValueChange = { openingBal = it },
                        label = "प्रारंभिक (पिछला) बैलेंस (₹)",
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (partyName.isNotBlank()) {
                            viewModel.repository.saveParty(
                                module = "CHAMDA_SALES",
                                name = partyName,
                                openingBalance = openingBal,
                                existingId = editingParty?.id
                            )
                            showPartyDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                ) {
                    Text("सहेजें", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showPartyDialog = false }) { Text("रद्द करें") }
            }
        )
    }

    partyToDelete?.let { party ->
        ConfirmDeleteDialog(
            message = "क्या आप चमड़ा बिक्री पार्टी '${party.name}' को हटाना चाहते हैं?",
            onConfirm = { viewModel.repository.deleteParty(party) },
            onDismiss = { partyToDelete = null }
        )
    }

    if (showBikriDialog && activeParty != null) {
        var date by remember { mutableStateOf(editingBikri?.date ?: DateAndFormatUtils.todayFormatted()) }
        var badaCount by remember { mutableStateOf(editingBikri?.badaChamdaCount ?: "0") }
        var badaRate by remember { mutableStateOf(editingBikri?.badaChamdaRate ?: "0.00") }
        var veelCount by remember { mutableStateOf(editingBikri?.veelChamdaCount ?: "0") }
        var veelRate by remember { mutableStateOf(editingBikri?.veelChamdaRate ?: "0.00") }
        var receivedPayment by remember { mutableStateOf(editingBikri?.receivedPayment ?: "0.00") }
        var paymentDate by remember { mutableStateOf(editingBikri?.paymentDate ?: DateAndFormatUtils.todayFormatted()) }

        val badaAmt = AccountingCalculator.multiply(badaCount, badaRate)
        val veelAmt = AccountingCalculator.multiply(veelCount, veelRate)
        val totalSaleAmt = badaAmt.add(veelAmt)

        AlertDialog(
            onDismissRequest = { showBikriDialog = false },
            title = { Text("चमड़ा बिक्री एंट्री (${activeParty.name})") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        label = { Text("1. तारीख (DD-MM-YYYY)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        HindiDecimalField(
                            value = badaCount,
                            onValueChange = { badaCount = it },
                            label = "3. बड़ा चमड़ा संख्या",
                            modifier = Modifier.weight(1f)
                        )
                        HindiDecimalField(
                            value = badaRate,
                            onValueChange = { badaRate = it },
                            label = "4. बड़ा चमड़ा रेट (₹)",
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Text("5. बड़ा चमड़ा रकम: ${DateAndFormatUtils.formatIndianCurrency(badaAmt.toPlainString())}")

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        HindiDecimalField(
                            value = veelCount,
                            onValueChange = { veelCount = it },
                            label = "6. वील चमड़ा संख्या",
                            modifier = Modifier.weight(1f)
                        )
                        HindiDecimalField(
                            value = veelRate,
                            onValueChange = { veelRate = it },
                            label = "7. वील चमड़ा रेट (₹)",
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Text("8. वील चमड़ा रकम: ${DateAndFormatUtils.formatIndianCurrency(veelAmt.toPlainString())}")
                    Text(
                        text = "9. कुल बिक्री रकम: ${DateAndFormatUtils.formatIndianCurrency(totalSaleAmt.toPlainString())}",
                        fontWeight = FontWeight.Bold,
                        color = HaweliDarkGreen
                    )
                    HindiDecimalField(
                        value = receivedPayment,
                        onValueChange = { receivedPayment = it },
                        label = "11. प्राप्त भुगतान (₹ - लाल रंग)",
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = paymentDate,
                        onValueChange = { paymentDate = it },
                        label = { Text("12. भुगतान की तारीख (DD-MM-YYYY)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val candidate = ChamdaBikriEntry(
                            id = editingBikri?.id ?: "",
                            date = date,
                            partyId = activeParty.id,
                            partyName = activeParty.name,
                            badaChamdaCount = badaCount,
                            badaChamdaRate = badaRate,
                            veelChamdaCount = veelCount,
                            veelChamdaRate = veelRate,
                            receivedPayment = receivedPayment,
                            paymentDate = paymentDate,
                            createdAt = editingBikri?.createdAt ?: System.currentTimeMillis()
                        )
                        val (wouldGoNegative, warningMsg) =
                            viewModel.repository.wouldChamdaStockBecomeNegative(candidate)
                        if (wouldGoNegative) {
                            pendingNegativeStockDraft = candidate
                            negativeStockWarningText = warningMsg
                            showBikriDialog = false
                        } else {
                            viewModel.repository.saveChamdaBikriEntry(activeParty, candidate)
                            showBikriDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
                ) {
                    Text("बिक्री सहेजें", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showBikriDialog = false }) { Text("रद्द करें") }
            }
        )
    }

    // Admin Warning when stock would become negative
    pendingNegativeStockDraft?.let { draft ->
        if (activeParty != null) {
            AlertDialog(
                onDismissRequest = { pendingNegativeStockDraft = null },
                title = { Text("नकारात्मक स्टॉक चेतावनी!", color = HaweliPaymentRed, fontWeight = FontWeight.Bold) },
                text = { Text(negativeStockWarningText) },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.repository.saveChamdaBikriEntry(
                                activeParty,
                                draft.copy(adminNegativeStockApproved = true)
                            )
                            pendingNegativeStockDraft = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = HaweliPaymentRed)
                    ) {
                        Text("हाँ, एडमिन अनुमति से सहेजें", color = Color.White)
                    }
                },
                dismissButton = {
                    OutlinedButton(onClick = { pendingNegativeStockDraft = null }) {
                        Text("रद्द करें")
                    }
                }
            )
        }
    }

    bikriToDelete?.let { sale ->
        if (activeParty != null) {
            ConfirmDeleteDialog(
                message = "क्या आप तारीख ${sale.date} की चमड़ा बिक्री एंट्री हटाना चाहते हैं?",
                onConfirm = { viewModel.repository.deleteChamdaBikriEntry(activeParty, sale.id) },
                onDismiss = { bikriToDelete = null }
            )
        }
    }
}
