package com.haweli.admin

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haweli.models.AccessRole
import com.haweli.ui.theme.HaweliDarkGreen
import com.haweli.ui.theme.HaweliNavyBlue
import com.haweli.ui.theme.HaweliPaymentRed

/**
 * Renders `content` ONLY when the authenticated user holds the verified ADMIN role.
 */
@Composable
fun AdminOnlySection(
    accessRole: AccessRole,
    content: @Composable () -> Unit
) {
    if (accessRole == AccessRole.ADMIN) {
        content()
    }
}

/**
 * Mandatory dialog displayed immediately after the Admin's first login with initial credentials
 * ("Haweli" / "Haweli"), forcing a secure password change before editing records.
 */
@Composable
fun ForcePasswordChangeDialog(
    errorMessage: String?,
    isBusy: Boolean,
    onSubmitNewPassword: (currentPass: String, newPass: String, confirmPass: String) -> Unit
) {
    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = { /* Mandatory on first login */ },
        icon = {
            Icon(
                imageVector = Icons.Default.Security,
                contentDescription = "सुरक्षा",
                tint = HaweliDarkGreen
            )
        },
        title = {
            Text(
                text = "प्रथम एडमिन लॉगिन: पासवर्ड बदलना अनिवार्य है",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = HaweliNavyBlue
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "सुरक्षा नियमों के अनुसार, प्रारंभिक पासवर्ड ('Haweli') से लॉगिन करने के बाद अपना नया गुप्त पासवर्ड सेट करना आवश्यक है।",
                    fontSize = 14.sp
                )
                OutlinedTextField(
                    value = currentPassword,
                    onValueChange = { currentPassword = it },
                    label = { Text("वर्तमान पासवर्ड") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = newPassword,
                    onValueChange = { newPassword = it },
                    label = { Text("नया पासवर्ड (कम से कम 6 अक्षर)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it },
                    label = { Text("नया पासवर्ड पुनः लिखें") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (!errorMessage.isNullOrBlank()) {
                    Text(
                        text = errorMessage,
                        color = HaweliPaymentRed,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmitNewPassword(currentPassword, newPassword, confirmPassword) },
                enabled = !isBusy,
                colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
            ) {
                Text(
                    text = if (isBusy) "अपडेट हो रहा है..." else "पासवर्ड बदलें और जारी रखें",
                    color = Color.White
                )
            }
        }
    )
}

/**
 * Admin Login Dialog used in Settings or from the lock icon.
 */
@Composable
fun AdminLoginDialog(
    errorMessage: String?,
    isBusy: Boolean,
    onLoginSubmit: (username: String, password: String) -> Unit,
    onDismiss: () -> Unit
) {
    var username by remember { mutableStateOf("Haweli") }
    var password by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "एडमिन लॉगिन",
                tint = HaweliNavyBlue
            )
        },
        title = {
            Text(
                text = "एडमिन लॉगिन (HAWELI)",
                fontWeight = FontWeight.Bold,
                color = HaweliNavyBlue
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "हिसाब जोड़ने, बदलने या हटाने के लिए एडमिन यूज़रनेम और पासवर्ड दर्ज करें।",
                    fontSize = 14.sp
                )
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("एडमिन यूज़रनेम") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("पासवर्ड") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (!errorMessage.isNullOrBlank()) {
                    Text(
                        text = errorMessage,
                        color = HaweliPaymentRed,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onLoginSubmit(username, password) },
                enabled = !isBusy,
                colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkGreen)
            ) {
                Text(if (isBusy) "सत्यापन हो रहा है..." else "लॉगिन करें", color = Color.White)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("रद्द करें")
            }
        }
    )
}
