package com.haweli.repository

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.haweli.calculations.AccountingCalculator
import com.haweli.database.DatabasePaths
import com.haweli.firebase.FirebaseClient
import com.haweli.models.*
import com.haweli.utils.DateAndFormatUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.math.BigDecimal
import java.util.UUID

/**
 * Central realtime repository for HAWELI.
 * Synchronizes all 8 modules with Firebase Realtime Database (`https://haweli123-default-rtdb.firebaseio.com/`),
 * supports offline queuing (`setValue` / `updateChildren` fire immediately against local persistence cache
 * and sync automatically when internet returns), prevents duplicate entries via deterministic UUIDs,
 * and recalculates running party balances and dashboard totals whenever any transaction is added, edited, or deleted.
 */
class HaweliRepository {

    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _cities = MutableStateFlow<List<CityRecord>>(emptyList())
    val cities: StateFlow<List<CityRecord>> = _cities.asStateFlow()

    private val _parties = MutableStateFlow<List<PartyRecord>>(emptyList())
    val parties: StateFlow<List<PartyRecord>> = _parties.asStateFlow()

    private val _fourPcEntries = MutableStateFlow<List<FourPcEntry>>(emptyList())
    val fourPcEntries: StateFlow<List<FourPcEntry>> = _fourPcEntries.asStateFlow()

    private val _hyderabadEntries = MutableStateFlow<List<HyderabadEntry>>(emptyList())
    val hyderabadEntries: StateFlow<List<HyderabadEntry>> = _hyderabadEntries.asStateFlow()

    private val _chamdaOpeningStock = MutableStateFlow(ChamdaOpeningStock())
    val chamdaOpeningStock: StateFlow<ChamdaOpeningStock> = _chamdaOpeningStock.asStateFlow()

    private val _chamdaAwakEntries = MutableStateFlow<List<ChamdaAwakEntry>>(emptyList())
    val chamdaAwakEntries: StateFlow<List<ChamdaAwakEntry>> = _chamdaAwakEntries.asStateFlow()

    private val _chamdaBikriEntries = MutableStateFlow<List<ChamdaBikriEntry>>(emptyList())
    val chamdaBikriEntries: StateFlow<List<ChamdaBikriEntry>> = _chamdaBikriEntries.asStateFlow()

    private val _kenaEntries = MutableStateFlow<List<KenaEntry>>(emptyList())
    val kenaEntries: StateFlow<List<KenaEntry>> = _kenaEntries.asStateFlow()

    private val _potliEntries = MutableStateFlow<List<PotliEntry>>(emptyList())
    val potliEntries: StateFlow<List<PotliEntry>> = _potliEntries.asStateFlow()

    private val _vehicleEntries = MutableStateFlow<List<VehicleEntry>>(emptyList())
    val vehicleEntries: StateFlow<List<VehicleEntry>> = _vehicleEntries.asStateFlow()

    private val _payments = MutableStateFlow<List<PaymentRecord>>(emptyList())
    val payments: StateFlow<List<PaymentRecord>> = _payments.asStateFlow()

    private val _reports = MutableStateFlow<List<ReportMetadata>>(emptyList())
    val reports: StateFlow<List<ReportMetadata>> = _reports.asStateFlow()

    private val _dashboardTotals = MutableStateFlow(DashboardTotals())
    val dashboardTotals: StateFlow<DashboardTotals> = _dashboardTotals.asStateFlow()

    private val _pendingWriteCount = MutableStateFlow(0)
    val pendingWriteCount: StateFlow<Int> = _pendingWriteCount.asStateFlow()

    private var listenersAttached = false

    fun startRealtimeListeners() {
        if (listenersAttached) return
        listenersAttached = true

        try {
            FirebaseClient.ref(DatabasePaths.SETTINGS)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        snapshot.getValue(AppSettings::class.java)?.let {
                            _settings.value = it
                        }
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.CITIES)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(CityRecord::class.java)
                        }.sortedBy { it.name }
                        _cities.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.PARTIES)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(PartyRecord::class.java)
                        }.sortedBy { it.name }
                        _parties.value = list
                        _dashboardTotals.value = AccountingCalculator.calculateDashboardTotals(list)
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.FOUR_PC_PARTIES)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(FourPcEntry::class.java)
                        }.sortedWith(compareByDescending<FourPcEntry> { it.dateEpoch }.thenByDescending { it.createdAt })
                        _fourPcEntries.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.HYDERABAD_COMPANY)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(HyderabadEntry::class.java)
                        }.sortedWith(compareByDescending<HyderabadEntry> { it.dateEpoch }.thenByDescending { it.createdAt })
                        _hyderabadEntries.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.CHAMDA_OPENING_STOCK)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        snapshot.getValue(ChamdaOpeningStock::class.java)?.let {
                            _chamdaOpeningStock.value = it
                        }
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.CHAMDA_PURCHASES)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(ChamdaAwakEntry::class.java)
                        }.sortedWith(compareByDescending<ChamdaAwakEntry> { it.dateEpoch }.thenByDescending { it.createdAt })
                        _chamdaAwakEntries.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.CHAMDA_SALES)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(ChamdaBikriEntry::class.java)
                        }.sortedWith(compareByDescending<ChamdaBikriEntry> { it.dateEpoch }.thenByDescending { it.createdAt })
                        _chamdaBikriEntries.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.KENA)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(KenaEntry::class.java)
                        }.sortedWith(compareByDescending<KenaEntry> { it.dateEpoch }.thenByDescending { it.createdAt })
                        _kenaEntries.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.POTLI)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(PotliEntry::class.java)
                        }.sortedWith(compareByDescending<PotliEntry> { it.dateEpoch }.thenByDescending { it.createdAt })
                        _potliEntries.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.VEHICLES)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(VehicleEntry::class.java)
                        }.sortedWith(compareByDescending<VehicleEntry> { it.dateEpoch }.thenByDescending { it.createdAt })
                        _vehicleEntries.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.PAYMENTS)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(PaymentRecord::class.java)
                        }.sortedByDescending { it.dateEpoch }
                        _payments.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })

            FirebaseClient.ref(DatabasePaths.REPORTS)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list = snapshot.children.mapNotNull {
                            it.getValue(ReportMetadata::class.java)
                        }.sortedByDescending { it.createdAt }
                        _reports.value = list
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })
        } catch (_: Exception) {
        }
    }

    private fun trackWrite(refPath: String, value: Any?) {
        _pendingWriteCount.value += 1
        FirebaseClient.ref(refPath).setValue(value).addOnCompleteListener {
            _pendingWriteCount.value = (_pendingWriteCount.value - 1).coerceAtLeast(0)
        }
    }

    private fun trackAtomicMultiPathUpdate(updates: Map<String, Any?>) {
        _pendingWriteCount.value += 1
        FirebaseClient.ref(DatabasePaths.ROOT).updateChildren(updates).addOnCompleteListener {
            _pendingWriteCount.value = (_pendingWriteCount.value - 1).coerceAtLeast(0)
        }
    }

    // =========================================================================
    // 1. CITY MANAGEMENT (शहर प्रबंधन)
    // =========================================================================

    fun saveCity(cityName: String, existingId: String? = null) {
        val cleanName = cityName.trim()
        if (cleanName.isEmpty()) return
        val id = existingId ?: UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val existing = _cities.value.find { it.id == id }
        val record = CityRecord(
            id = id,
            name = cleanName,
            createdAt = existing?.createdAt ?: now,
            updatedAt = now
        )
        trackWrite("${DatabasePaths.CITIES}/$id", record)
    }

    fun deleteCity(cityId: String) {
        val updates = mutableMapOf<String, Any?>("cities/$cityId" to null)
        // Also remove parties and entries belonging to this city
        _parties.value.filter { it.cityId == cityId }.forEach { party ->
            updates["parties/${party.id}"] = null
        }
        _fourPcEntries.value.filter { it.cityId == cityId }.forEach { entry ->
            updates["fourPcParties/${entry.id}"] = null
            updates["payments/${entry.id}"] = null
        }
        trackAtomicMultiPathUpdate(updates)
    }

    // =========================================================================
    // 2. PARTY MANAGEMENT (पार्टी प्रबंधन - सभी मॉड्यूल)
    // =========================================================================

    fun saveParty(
        module: String,
        name: String,
        cityId: String = "",
        cityName: String = "",
        phone: String = "",
        openingBalance: String = "0.00",
        existingId: String? = null
    ) {
        val cleanName = name.trim()
        if (cleanName.isEmpty()) return
        val id = existingId ?: UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val existing = _parties.value.find { it.id == id }
        val openBalDec = AccountingCalculator.parseDecimal(openingBalance)
        val openBalFormatted = AccountingCalculator.formatDecimal(openBalDec)

        val baseParty = PartyRecord(
            id = id,
            module = module,
            cityId = cityId,
            cityName = cityName,
            name = cleanName,
            phone = phone.trim(),
            openingBalance = openBalFormatted,
            currentBalance = existing?.currentBalance ?: openBalFormatted,
            balanceStatus = existing?.balanceStatus ?: resolveStatusLabel(module, openBalDec),
            createdAt = existing?.createdAt ?: now,
            updatedAt = now
        )

        val updates = mutableMapOf<String, Any?>(
            "parties/$id" to baseParty
        )
        if (module == "CHAMDA_SALES") {
            updates["chamda/parties/$id"] = baseParty
        }
        trackAtomicMultiPathUpdate(updates)

        // Recalculate party ledger chain in case openingBalance or name changed
        recalculateAndPersistPartyLedger(baseParty)
    }

    fun deleteParty(party: PartyRecord) {
        val updates = mutableMapOf<String, Any?>(
            "parties/${party.id}" to null
        )
        when (party.module) {
            "FOUR_PC" -> _fourPcEntries.value.filter { it.partyId == party.id }.forEach {
                updates["fourPcParties/${it.id}"] = null
                updates["payments/${it.id}"] = null
            }
            "HYDERABAD" -> _hyderabadEntries.value.filter { it.partyId == party.id }.forEach {
                updates["hyderabadCompany/${it.id}"] = null
                updates["payments/${it.id}"] = null
            }
            "CHAMDA_SALES" -> {
                updates["chamda/parties/${party.id}"] = null
                _chamdaBikriEntries.value.filter { it.partyId == party.id }.forEach {
                    updates["chamda/sales/${it.id}"] = null
                    updates["sales/${it.id}"] = null
                    updates["payments/${it.id}"] = null
                }
            }
            "KENA" -> _kenaEntries.value.filter { it.partyId == party.id }.forEach {
                updates["kena/${it.id}"] = null
                updates["payments/${it.id}"] = null
            }
            "POTLI" -> _potliEntries.value.filter { it.partyId == party.id }.forEach {
                updates["potli/${it.id}"] = null
                updates["payments/${it.id}"] = null
            }
        }
        trackAtomicMultiPathUpdate(updates)
    }

    private fun resolveStatusLabel(module: String, balance: BigDecimal): String {
        return if (module == "FOUR_PC") {
            AccountingCalculator.resolvePayableStatus(balance).hindiLabel
        } else {
            AccountingCalculator.resolveReceivableStatus(balance).hindiLabel
        }
    }

    // =========================================================================
    // 3. 4PC PARTY LEDGER ENTRIES (4PC पार्टी हिसाब)
    // =========================================================================

    fun saveFourPcEntry(party: PartyRecord, draft: FourPcEntry) {
        val now = System.currentTimeMillis()
        val id = draft.id.ifBlank { UUID.randomUUID().toString() }
        val normalizedDate = DateAndFormatUtils.normalizeDate(draft.date)
        val normalizedPayDate = if (draft.paymentDate.isNotBlank()) {
            DateAndFormatUtils.normalizeDate(draft.paymentDate)
        } else {
            normalizedDate
        }

        val candidate = draft.copy(
            id = id,
            cityId = party.cityId,
            cityName = party.cityName,
            partyId = party.id,
            partyName = party.name,
            date = normalizedDate,
            dateEpoch = DateAndFormatUtils.parseDateToEpoch(normalizedDate),
            monthYear = DateAndFormatUtils.extractMonthYear(normalizedDate),
            paymentDate = normalizedPayDate,
            updatedAt = now
        )

        val currentEntries = _fourPcEntries.value
            .filter { it.partyId == party.id && it.id != id } + candidate

        persistFourPcChain(party, currentEntries)
    }

    fun deleteFourPcEntry(party: PartyRecord, entryId: String) {
        val remaining = _fourPcEntries.value.filter { it.partyId == party.id && it.id != entryId }
        val updates = mutableMapOf<String, Any?>(
            "fourPcParties/$entryId" to null,
            "payments/$entryId" to null
        )
        val (recalculated, finalBal) = AccountingCalculator.recalculateFourPcPartyChain(
            party.openingBalance,
            remaining
        )
        recalculated.forEach { e ->
            updates["fourPcParties/${e.id}"] = e
            updates["payments/${e.id}"] = buildPaymentRecord(
                id = e.id,
                module = "FOUR_PC",
                partyId = party.id,
                partyName = party.name,
                paymentDate = e.paymentDate.ifBlank { e.date },
                amount = e.paymentAmount,
                type = "PAID"
            )
        }
        val status = AccountingCalculator.resolvePayableStatus(finalBal).hindiLabel
        updates["parties/${party.id}"] = party.copy(
            currentBalance = AccountingCalculator.formatDecimal(finalBal),
            balanceStatus = status,
            updatedAt = System.currentTimeMillis()
        )
        trackAtomicMultiPathUpdate(updates)
    }

    private fun persistFourPcChain(party: PartyRecord, entries: List<FourPcEntry>) {
        val (recalculated, finalBal) = AccountingCalculator.recalculateFourPcPartyChain(
            party.openingBalance,
            entries
        )
        val updates = mutableMapOf<String, Any?>()
        recalculated.forEach { e ->
            updates["fourPcParties/${e.id}"] = e
            updates["payments/${e.id}"] = buildPaymentRecord(
                id = e.id,
                module = "FOUR_PC",
                partyId = party.id,
                partyName = party.name,
                paymentDate = e.paymentDate.ifBlank { e.date },
                amount = e.paymentAmount,
                type = "PAID"
            )
        }
        val status = AccountingCalculator.resolvePayableStatus(finalBal).hindiLabel
        updates["parties/${party.id}"] = party.copy(
            currentBalance = AccountingCalculator.formatDecimal(finalBal),
            balanceStatus = status,
            updatedAt = System.currentTimeMillis()
        )
        trackAtomicMultiPathUpdate(updates)
    }

    // =========================================================================
    // 4. HYDERABAD COMPANY ENTRIES (हैदराबाद कंपनी हिसाब)
    // =========================================================================

    fun saveHyderabadEntry(party: PartyRecord, draft: HyderabadEntry) {
        val now = System.currentTimeMillis()
        val id = draft.id.ifBlank { UUID.randomUUID().toString() }
        val normalizedDate = DateAndFormatUtils.normalizeDate(draft.date)
        val normalizedPayDate = if (draft.paymentDate.isNotBlank()) {
            DateAndFormatUtils.normalizeDate(draft.paymentDate)
        } else {
            normalizedDate
        }

        val candidate = draft.copy(
            id = id,
            partyId = party.id,
            partyName = party.name,
            date = normalizedDate,
            dateEpoch = DateAndFormatUtils.parseDateToEpoch(normalizedDate),
            monthYear = DateAndFormatUtils.extractMonthYear(normalizedDate),
            paymentDate = normalizedPayDate,
            updatedAt = now
        )

        val currentEntries = _hyderabadEntries.value
            .filter { it.partyId == party.id && it.id != id } + candidate

        persistHyderabadChain(party, currentEntries)
    }

    fun deleteHyderabadEntry(party: PartyRecord, entryId: String) {
        val remaining = _hyderabadEntries.value.filter { it.partyId == party.id && it.id != entryId }
        val updates = mutableMapOf<String, Any?>(
            "hyderabadCompany/$entryId" to null,
            "payments/$entryId" to null
        )
        val (recalculated, finalBal) = AccountingCalculator.recalculateHyderabadPartyChain(
            party.openingBalance,
            remaining
        )
        recalculated.forEach { e ->
            updates["hyderabadCompany/${e.id}"] = e
            updates["payments/${e.id}"] = buildPaymentRecord(
                id = e.id,
                module = "HYDERABAD",
                partyId = party.id,
                partyName = party.name,
                paymentDate = e.paymentDate.ifBlank { e.date },
                amount = e.receivedPayment,
                type = "RECEIVED"
            )
        }
        val status = AccountingCalculator.resolveReceivableStatus(finalBal).hindiLabel
        updates["parties/${party.id}"] = party.copy(
            currentBalance = AccountingCalculator.formatDecimal(finalBal),
            balanceStatus = status,
            updatedAt = System.currentTimeMillis()
        )
        trackAtomicMultiPathUpdate(updates)
    }

    private fun persistHyderabadChain(party: PartyRecord, entries: List<HyderabadEntry>) {
        val (recalculated, finalBal) = AccountingCalculator.recalculateHyderabadPartyChain(
            party.openingBalance,
            entries
        )
        val updates = mutableMapOf<String, Any?>()
        recalculated.forEach { e ->
            updates["hyderabadCompany/${e.id}"] = e
            updates["payments/${e.id}"] = buildPaymentRecord(
                id = e.id,
                module = "HYDERABAD",
                partyId = party.id,
                partyName = party.name,
                paymentDate = e.paymentDate.ifBlank { e.date },
                amount = e.receivedPayment,
                type = "RECEIVED"
            )
        }
        val status = AccountingCalculator.resolveReceivableStatus(finalBal).hindiLabel
        updates["parties/${party.id}"] = party.copy(
            currentBalance = AccountingCalculator.formatDecimal(finalBal),
            balanceStatus = status,
            updatedAt = System.currentTimeMillis()
        )
        trackAtomicMultiPathUpdate(updates)
    }

    // =========================================================================
    // 5. CHAMDA MANAGEMENT (चमड़ा आवक एवं चमड़ा बिक्री)
    // =========================================================================

    fun saveChamdaOpeningStock(badaCount: String, veelCount: String) {
        val stock = ChamdaOpeningStock(
            openingBadaChamda = AccountingCalculator.parseDecimal(badaCount).setScale(0).toPlainString(),
            openingVeelChamda = AccountingCalculator.parseDecimal(veelCount).setScale(0).toPlainString(),
            updatedAt = System.currentTimeMillis()
        )
        trackWrite(DatabasePaths.CHAMDA_OPENING_STOCK, stock)
    }

    fun saveChamdaAwakEntry(draft: ChamdaAwakEntry) {
        val id = draft.id.ifBlank { UUID.randomUUID().toString() }
        val normalizedDate = DateAndFormatUtils.normalizeDate(draft.date)
        val badaCount = AccountingCalculator.parseDecimal(draft.badaChamdaCount).setScale(0)
        val veelCount = AccountingCalculator.parseDecimal(draft.veelChamdaCount).setScale(0)
        val totalCount = badaCount.add(veelCount)
        val badaWeight = AccountingCalculator.parseDecimal(draft.badaChamdaWeight)
        val veelWeight = AccountingCalculator.parseDecimal(draft.veelChamdaWeight)
        val totalWeight = badaWeight.add(veelWeight)

        val record = draft.copy(
            id = id,
            date = normalizedDate,
            dateEpoch = DateAndFormatUtils.parseDateToEpoch(normalizedDate),
            monthYear = DateAndFormatUtils.extractMonthYear(normalizedDate),
            year = DateAndFormatUtils.extractYear(normalizedDate),
            badaChamdaCount = badaCount.toPlainString(),
            badaChamdaWeight = AccountingCalculator.formatDecimal(badaWeight),
            veelChamdaCount = veelCount.toPlainString(),
            veelChamdaWeight = AccountingCalculator.formatDecimal(veelWeight),
            totalChamdaCount = totalCount.toPlainString(),
            totalWeight = AccountingCalculator.formatDecimal(totalWeight),
            updatedAt = System.currentTimeMillis()
        )

        val updates = mapOf(
            "chamda/purchases/$id" to record,
            "purchases/$id" to record
        )
        trackAtomicMultiPathUpdate(updates)
    }

    fun deleteChamdaAwakEntry(entryId: String) {
        val updates = mapOf(
            "chamda/purchases/$entryId" to null,
            "purchases/$entryId" to null
        )
        trackAtomicMultiPathUpdate(updates)
    }

    /**
     * Checks whether saving a Chamda Bikri entry would cause closing stock to become negative.
     */
    fun wouldChamdaStockBecomeNegative(draft: ChamdaBikriEntry): Pair<Boolean, String> {
        val currentMonth = DateAndFormatUtils.currentMonthYear()
        val otherSales = _chamdaBikriEntries.value.filter { it.id != draft.id }
        val candidateSales = otherSales + draft
        val summaryAfter = AccountingCalculator.calculateChamdaStockSummary(
            openingStock = _chamdaOpeningStock.value,
            allAwak = _chamdaAwakEntries.value,
            allBikri = candidateSales,
            targetMonthYear = currentMonth
        )
        val closeBada = AccountingCalculator.parseDecimal(summaryAfter.closingBadaStock)
        val closeVeel = AccountingCalculator.parseDecimal(summaryAfter.closingVeelStock)
        return if (closeBada < BigDecimal.ZERO || closeVeel < BigDecimal.ZERO) {
            Pair(
                true,
                "चेतावनी: इस बिक्री के बाद स्टॉक नकारात्मक हो जाएगा (बचा बड़ा चमड़ा: ${summaryAfter.closingBadaStock}, बचा वील चमड़ा: ${summaryAfter.closingVeelStock})। क्या आप फिर भी एडमिन के रूप में इसे सहेजना चाहते हैं?"
            )
        } else {
            Pair(false, "")
        }
    }

    fun saveChamdaBikriEntry(party: PartyRecord, draft: ChamdaBikriEntry) {
        val now = System.currentTimeMillis()
        val id = draft.id.ifBlank { UUID.randomUUID().toString() }
        val normalizedDate = DateAndFormatUtils.normalizeDate(draft.date)
        val normalizedPayDate = if (draft.paymentDate.isNotBlank()) {
            DateAndFormatUtils.normalizeDate(draft.paymentDate)
        } else {
            normalizedDate
        }

        val candidate = draft.copy(
            id = id,
            partyId = party.id,
            partyName = party.name,
            date = normalizedDate,
            dateEpoch = DateAndFormatUtils.parseDateToEpoch(normalizedDate),
            monthYear = DateAndFormatUtils.extractMonthYear(normalizedDate),
            year = DateAndFormatUtils.extractYear(normalizedDate),
            paymentDate = normalizedPayDate,
            updatedAt = now
        )

        val currentEntries = _chamdaBikriEntries.value
            .filter { it.partyId == party.id && it.id != id } + candidate

        persistChamdaBikriChain(party, currentEntries)
    }

    fun deleteChamdaBikriEntry(party: PartyRecord, entryId: String) {
        val remaining = _chamdaBikriEntries.value.filter { it.partyId == party.id && it.id != entryId }
        val updates = mutableMapOf<String, Any?>(
            "chamda/sales/$entryId" to null,
            "sales/$entryId" to null,
            "payments/$entryId" to null
        )
        val (recalculated, finalBal) = AccountingCalculator.recalculateChamdaBikriPartyChain(
            party.openingBalance,
            remaining
        )
        recalculated.forEach { e ->
            updates["chamda/sales/${e.id}"] = e
            updates["sales/${e.id}"] = e
            updates["payments/${e.id}"] = buildPaymentRecord(
                id = e.id,
                module = "CHAMDA_SALES",
                partyId = party.id,
                partyName = party.name,
                paymentDate = e.paymentDate.ifBlank { e.date },
                amount = e.receivedPayment,
                type = "RECEIVED"
            )
        }
        val status = AccountingCalculator.resolveReceivableStatus(finalBal).hindiLabel
        val updatedParty = party.copy(
            currentBalance = AccountingCalculator.formatDecimal(finalBal),
            balanceStatus = status,
            updatedAt = System.currentTimeMillis()
        )
        updates["parties/${party.id}"] = updatedParty
        updates["chamda/parties/${party.id}"] = updatedParty
        trackAtomicMultiPathUpdate(updates)
    }

    private fun persistChamdaBikriChain(party: PartyRecord, entries: List<ChamdaBikriEntry>) {
        val (recalculated, finalBal) = AccountingCalculator.recalculateChamdaBikriPartyChain(
            party.openingBalance,
            entries
        )
        val updates = mutableMapOf<String, Any?>()
        recalculated.forEach { e ->
            updates["chamda/sales/${e.id}"] = e
            updates["sales/${e.id}"] = e
            updates["payments/${e.id}"] = buildPaymentRecord(
                id = e.id,
                module = "CHAMDA_SALES",
                partyId = party.id,
                partyName = party.name,
                paymentDate = e.paymentDate.ifBlank { e.date },
                amount = e.receivedPayment,
                type = "RECEIVED"
            )
        }
        val status = AccountingCalculator.resolveReceivableStatus(finalBal).hindiLabel
        val updatedParty = party.copy(
            currentBalance = AccountingCalculator.formatDecimal(finalBal),
            balanceStatus = status,
            updatedAt = System.currentTimeMillis()
        )
        updates["parties/${party.id}"] = updatedParty
        updates["chamda/parties/${party.id}"] = updatedParty
        trackAtomicMultiPathUpdate(updates)
    }

    // =========================================================================
    // 6. KENA MANAGEMENT (केना हिसाब)
    // =========================================================================

    fun saveKenaEntry(party: PartyRecord, draft: KenaEntry) {
        val now = System.currentTimeMillis()
        val id = draft.id.ifBlank { UUID.randomUUID().toString() }
        val normalizedDate = DateAndFormatUtils.normalizeDate(draft.date)
        val normalizedPayDate = if (draft.paymentDate.isNotBlank()) {
            DateAndFormatUtils.normalizeDate(draft.paymentDate)
        } else {
            normalizedDate
        }

        val candidate = draft.copy(
            id = id,
            partyId = party.id,
            partyName = party.name,
            date = normalizedDate,
            dateEpoch = DateAndFormatUtils.parseDateToEpoch(normalizedDate),
            monthYear = DateAndFormatUtils.extractMonthYear(normalizedDate),
            paymentDate = normalizedPayDate,
            updatedAt = now
        )

        val currentEntries = _kenaEntries.value
            .filter { it.partyId == party.id && it.id != id } + candidate

        persistKenaChain(party, currentEntries)
    }

    fun deleteKenaEntry(party: PartyRecord, entryId: String) {
        val remaining = _kenaEntries.value.filter { it.partyId == party.id && it.id != entryId }
        val updates = mutableMapOf<String, Any?>(
            "kena/$entryId" to null,
            "payments/$entryId" to null
        )
        val (recalculated, finalBal) = AccountingCalculator.recalculateKenaPartyChain(
            party.openingBalance,
            remaining
        )
        recalculated.forEach { e ->
            updates["kena/${e.id}"] = e
            updates["payments/${e.id}"] = buildPaymentRecord(
                id = e.id,
                module = "KENA",
                partyId = party.id,
                partyName = party.name,
                paymentDate = e.paymentDate.ifBlank { e.date },
                amount = e.receivedPayment,
                type = "RECEIVED"
            )
        }
        val status = AccountingCalculator.resolveReceivableStatus(finalBal).hindiLabel
        updates["parties/${party.id}"] = party.copy(
            currentBalance = AccountingCalculator.formatDecimal(finalBal),
            balanceStatus = status,
            updatedAt = System.currentTimeMillis()
        )
        trackAtomicMultiPathUpdate(updates)
    }

    private fun persistKenaChain(party: PartyRecord, entries: List<KenaEntry>) {
        val (recalculated, finalBal) = AccountingCalculator.recalculateKenaPartyChain(
            party.openingBalance,
            entries
        )
        val updates = mutableMapOf<String, Any?>()
        recalculated.forEach { e ->
            updates["kena/${e.id}"] = e
            updates["payments/${e.id}"] = buildPaymentRecord(
                id = e.id,
                module = "KENA",
                partyId = party.id,
                partyName = party.name,
                paymentDate = e.paymentDate.ifBlank { e.date },
                amount = e.receivedPayment,
                type = "RECEIVED"
            )
        }
        val status = AccountingCalculator.resolveReceivableStatus(finalBal).hindiLabel
        updates["parties/${party.id}"] = party.copy(
            currentBalance = AccountingCalculator.formatDecimal(finalBal),
            balanceStatus = status,
            updatedAt = System.currentTimeMillis()
        )
        trackAtomicMultiPathUpdate(updates)
    }

    // =========================================================================
    // 7. POTLI MANAGEMENT (पोटली हिसाब)
    // =========================================================================

    fun savePotliEntry(party: PartyRecord, draft: PotliEntry) {
        val now = System.currentTimeMillis()
        val id = draft.id.ifBlank { UUID.randomUUID().toString() }
        val normalizedDate = DateAndFormatUtils.normalizeDate(draft.date)
        val normalizedPayDate = if (draft.paymentDate.isNotBlank()) {
            DateAndFormatUtils.normalizeDate(draft.paymentDate)
        } else {
            normalizedDate
        }

        val candidate = draft.copy(
            id = id,
            partyId = party.id,
            partyName = party.name,
            date = normalizedDate,
            dateEpoch = DateAndFormatUtils.parseDateToEpoch(normalizedDate),
            monthYear = DateAndFormatUtils.extractMonthYear(normalizedDate),
            paymentDate = normalizedPayDate,
            updatedAt = now
        )

        val currentEntries = _potliEntries.value
            .filter { it.partyId == party.id && it.id != id } + candidate

        persistPotliChain(party, currentEntries)
    }

    fun deletePotliEntry(party: PartyRecord, entryId: String) {
        val remaining = _potliEntries.value.filter { it.partyId == party.id && it.id != entryId }
        val updates = mutableMapOf<String, Any?>(
            "potli/$entryId" to null,
            "payments/$entryId" to null
        )
        val (recalculated, finalBal) = AccountingCalculator.recalculatePotliPartyChain(
            party.openingBalance,
            remaining
        )
        recalculated.forEach { e ->
            updates["potli/${e.id}"] = e
            updates["payments/${e.id}"] = buildPaymentRecord(
                id = e.id,
                module = "POTLI",
                partyId = party.id,
                partyName = party.name,
                paymentDate = e.paymentDate.ifBlank { e.date },
                amount = e.receivedPayment,
                type = "RECEIVED"
            )
        }
        val status = AccountingCalculator.resolveReceivableStatus(finalBal).hindiLabel
        updates["parties/${party.id}"] = party.copy(
            currentBalance = AccountingCalculator.formatDecimal(finalBal),
            balanceStatus = status,
            updatedAt = System.currentTimeMillis()
        )
        trackAtomicMultiPathUpdate(updates)
    }

    private fun persistPotliChain(party: PartyRecord, entries: List<PotliEntry>) {
        val (recalculated, finalBal) = AccountingCalculator.recalculatePotliPartyChain(
            party.openingBalance,
            entries
        )
        val updates = mutableMapOf<String, Any?>()
        recalculated.forEach { e ->
            updates["potli/${e.id}"] = e
            updates["payments/${e.id}"] = buildPaymentRecord(
                id = e.id,
                module = "POTLI",
                partyId = party.id,
                partyName = party.name,
                paymentDate = e.paymentDate.ifBlank { e.date },
                amount = e.receivedPayment,
                type = "RECEIVED"
            )
        }
        val status = AccountingCalculator.resolveReceivableStatus(finalBal).hindiLabel
        updates["parties/${party.id}"] = party.copy(
            currentBalance = AccountingCalculator.formatDecimal(finalBal),
            balanceStatus = status,
            updatedAt = System.currentTimeMillis()
        )
        trackAtomicMultiPathUpdate(updates)
    }

    // =========================================================================
    // 8. OBAD TO HYDERABAD GAADI (ओबाद से हैदराबाद गाड़ी)
    // =========================================================================

    fun saveVehicleEntry(draft: VehicleEntry) {
        val id = draft.id.ifBlank { UUID.randomUUID().toString() }
        val normalizedDate = DateAndFormatUtils.normalizeDate(draft.date)
        val enriched = AccountingCalculator.enrichVehicleEntry(
            draft.copy(
                id = id,
                date = normalizedDate,
                vehicleNumber = draft.vehicleNumber.trim().uppercase(),
                updatedAt = System.currentTimeMillis()
            )
        )
        trackWrite("${DatabasePaths.VEHICLES}/$id", enriched)
    }

    fun deleteVehicleEntry(entryId: String) {
        trackWrite("${DatabasePaths.VEHICLES}/$entryId", null)
    }

    // =========================================================================
    // 9. SETTINGS & REPORT METADATA LOGGING
    // =========================================================================

    fun saveAppSettings(newSettings: AppSettings) {
        trackWrite(DatabasePaths.SETTINGS, newSettings.copy(updatedAt = System.currentTimeMillis()))
    }

    fun recordGeneratedReport(metadata: ReportMetadata) {
        val id = metadata.id.ifBlank { UUID.randomUUID().toString() }
        trackWrite("${DatabasePaths.REPORTS}/$id", metadata.copy(id = id))
    }

    private fun recalculateAndPersistPartyLedger(party: PartyRecord) {
        when (party.module) {
            "FOUR_PC" -> persistFourPcChain(
                party,
                _fourPcEntries.value.filter { it.partyId == party.id }.map { it.copy(partyName = party.name) }
            )
            "HYDERABAD" -> persistHyderabadChain(
                party,
                _hyderabadEntries.value.filter { it.partyId == party.id }.map { it.copy(partyName = party.name) }
            )
            "CHAMDA_SALES" -> persistChamdaBikriChain(
                party,
                _chamdaBikriEntries.value.filter { it.partyId == party.id }.map { it.copy(partyName = party.name) }
            )
            "KENA" -> persistKenaChain(
                party,
                _kenaEntries.value.filter { it.partyId == party.id }.map { it.copy(partyName = party.name) }
            )
            "POTLI" -> persistPotliChain(
                party,
                _potliEntries.value.filter { it.partyId == party.id }.map { it.copy(partyName = party.name) }
            )
        }
    }

    private fun buildPaymentRecord(
        id: String,
        module: String,
        partyId: String,
        partyName: String,
        paymentDate: String,
        amount: String,
        type: String
    ): PaymentRecord? {
        val amtDec = AccountingCalculator.parseDecimal(amount)
        if (amtDec.compareTo(BigDecimal.ZERO) <= 0) return null
        return PaymentRecord(
            id = id,
            sourceEntryId = id,
            module = module,
            partyId = partyId,
            partyName = partyName,
            paymentDate = paymentDate,
            dateEpoch = DateAndFormatUtils.parseDateToEpoch(paymentDate),
            amount = AccountingCalculator.formatDecimal(amtDec),
            paymentType = type,
            updatedAt = System.currentTimeMillis()
        )
    }

    // =========================================================================
    // 10. FULL SNAPSHOT EXPORT & RESTORE FOR JSON BACKUP
    // =========================================================================

    fun buildBackupPayload(): HaweliBackupPayload {
        val now = System.currentTimeMillis()
        return HaweliBackupPayload(
            backupVersion = 1,
            applicationName = "HAWELI",
            backupTimestamp = now,
            backupDateFormatted = DateAndFormatUtils.formatTimestamp(now),
            settings = _settings.value,
            cities = _cities.value.associateBy { it.id },
            parties = _parties.value.associateBy { it.id },
            fourPcEntries = _fourPcEntries.value.associateBy { it.id },
            hyderabadEntries = _hyderabadEntries.value.associateBy { it.id },
            chamdaOpeningStock = _chamdaOpeningStock.value,
            chamdaAwakEntries = _chamdaAwakEntries.value.associateBy { it.id },
            chamdaBikriEntries = _chamdaBikriEntries.value.associateBy { it.id },
            kenaEntries = _kenaEntries.value.associateBy { it.id },
            potliEntries = _potliEntries.value.associateBy { it.id },
            vehicleEntries = _vehicleEntries.value.associateBy { it.id },
            payments = _payments.value.associateBy { it.id },
            reports = _reports.value.associateBy { it.id }
        )
    }

    fun restoreFromBackupPayload(payload: HaweliBackupPayload) {
        val updates = mutableMapOf<String, Any?>(
            "settings" to payload.settings,
            "cities" to payload.cities,
            "parties" to payload.parties,
            "fourPcParties" to payload.fourPcEntries,
            "hyderabadCompany" to payload.hyderabadEntries,
            "chamda/openingStock" to payload.chamdaOpeningStock,
            "chamda/purchases" to payload.chamdaAwakEntries,
            "purchases" to payload.chamdaAwakEntries,
            "chamda/sales" to payload.chamdaBikriEntries,
            "sales" to payload.chamdaBikriEntries,
            "chamda/parties" to payload.parties.filterValues { it.module == "CHAMDA_SALES" },
            "kena" to payload.kenaEntries,
            "potli" to payload.potliEntries,
            "vehicles" to payload.vehicleEntries,
            "payments" to payload.payments,
            "reports" to payload.reports
        )
        trackAtomicMultiPathUpdate(updates)
    }
}
