package com.haweli.calculations

import com.haweli.models.*
import org.junit.Assert.assertEquals
import org.junit.Test
import java.math.BigDecimal

/**
 * Unit tests verifying BigDecimal accuracy across all HAWELI accounting modules:
 * 4PC Party, Hyderabad Company, Chamda Stock & Sales, Kena, Potli, Obad vs Hyderabad Vehicle comparison,
 * and Home Dashboard (कुल आना / कुल देना) non-double-counted totals.
 */
class AccountingCalculatorTest {

    @Test
    fun testFourPcPartyRunningBalanceAndStatus() {
        val entry1 = FourPcEntry(
            id = "e1",
            date = "01-11-2026",
            dateEpoch = 1000L,
            badaMaalWeight = "120.50",
            badaMaalRate = "150.00",
            veelMaalWeight = "80.25",
            veelMaalRate = "100.00",
            paymentAmount = "10000.00"
        )
        val entry2 = FourPcEntry(
            id = "e2",
            date = "02-11-2026",
            dateEpoch = 2000L,
            badaMaalWeight = "50.00",
            badaMaalRate = "150.00",
            veelMaalWeight = "0.00",
            veelMaalRate = "100.00",
            paymentAmount = "25000.00"
        )

        val (chain, finalBal) = AccountingCalculator.recalculateFourPcPartyChain(
            openingBalance = "0.00",
            entries = listOf(entry2, entry1)
        )

        // Entry 1: bada = 120.50 * 150 = 18075.00, veel = 80.25 * 100 = 8025.00, total = 26100.00
        // paid = 10000.00 -> remaining = 16100.00 (बाकी देना)
        assertEquals("18075.00", chain[0].badaMaalAmount)
        assertEquals("8025.00", chain[0].veelMaalAmount)
        assertEquals("26100.00", chain[0].totalCombinedAmount)
        assertEquals("16100.00", chain[0].remainingBalance)
        assertEquals("बाकी देना", chain[0].balanceStatus)

        // Entry 2: prev = 16100.00, bada = 50 * 150 = 7500.00, total = 7500.00
        // paid = 25000.00 -> remaining = 16100 + 7500 - 25000 = -1400.00 (एडवांस)
        assertEquals("16100.00", chain[1].previousBalance)
        assertEquals("-1400.00", chain[1].remainingBalance)
        assertEquals("एडवांस", chain[1].balanceStatus)
        assertEquals(BigDecimal("-1400.00"), finalBal)
    }

    @Test
    fun testChamdaStockCalculation() {
        val opening = ChamdaOpeningStock(openingBadaChamda = "100", openingVeelChamda = "50")
        val awak = listOf(
            ChamdaAwakEntry(
                id = "a1",
                monthYear = "11-2026",
                badaChamdaCount = "250",
                veelChamdaCount = "150",
                totalWeight = "4200.50"
            )
        )
        val bikri = listOf(
            ChamdaBikriEntry(
                id = "b1",
                monthYear = "11-2026",
                badaChamdaCount = "180",
                veelChamdaCount = "120"
            )
        )

        val summary = AccountingCalculator.calculateChamdaStockSummary(
            openingStock = opening,
            allAwak = awak,
            allBikri = bikri,
            targetMonthYear = "11-2026"
        )

        // Opening + Awak - Sold: Bada = 100 + 250 - 180 = 170, Veel = 50 + 150 - 120 = 80
        assertEquals("250", summary.monthBadaAwak)
        assertEquals("150", summary.monthVeelAwak)
        assertEquals("180", summary.monthBadaSold)
        assertEquals("120", summary.monthVeelSold)
        assertEquals("170", summary.closingBadaStock)
        assertEquals("80", summary.closingVeelStock)
    }

    @Test
    fun testObadVsHyderabadVehicleComparison() {
        val v1 = AccountingCalculator.enrichVehicleEntry(
            VehicleEntry(
                id = "v1",
                date = "05-11-2026",
                vehicleNumber = "MH28AB1234",
                obadBadaWeight = "5000.00",
                obadVeelWeight = "2000.00",
                hyderabadBadaWeight = "4960.50",
                hyderabadVeelWeight = "1985.25"
            )
        )
        assertEquals("39.50", v1.badaWeightDiff)
        assertEquals("14.75", v1.veelWeightDiff)
        assertEquals("54.25", v1.totalWeightDiff)
    }

    @Test
    fun testDashboardNoDoubleCounting() {
        val parties = listOf(
            PartyRecord(id = "p1", module = "FOUR_PC", currentBalance = "15000.00"),
            PartyRecord(id = "p1", module = "FOUR_PC", currentBalance = "15000.00"), // duplicate guard
            PartyRecord(id = "p2", module = "HYDERABAD", currentBalance = "40000.00"),
            PartyRecord(id = "p3", module = "KENA", currentBalance = "5000.00"),
            PartyRecord(id = "p4", module = "POTLI", currentBalance = "3500.00")
        )
        val totals = AccountingCalculator.calculateDashboardTotals(parties)
        assertEquals("48500.00", totals.kulAana)
        assertEquals("15000.00", totals.kulDena)
    }
}
